"""Marimo notebooks shipped with the package.

Kept inside ``abguard`` rather than in a top-level ``notebooks/`` folder so they are
included in the built wheel and can be located with :mod:`importlib.resources` --
a repo-relative path only works for an editable install.
"""
