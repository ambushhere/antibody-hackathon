"""Liability check dashboard.

Run with ``abguard dashboard [FILE_OR_FOLDER]``, or directly:

    marimo run notebooks/dashboard.py     # read-only app
    marimo edit notebooks/dashboard.py    # editable notebook
    python notebooks/dashboard.py         # execute every cell as a script

Set ``ABGUARD_INPUT`` to preload a file, or a folder holding one file per team.
"""

import marimo

__generated_with = "0.13.0"
app = marimo.App(width="full", app_title="abguard · liability check")


@app.cell
def imports():
    import os
    import tempfile
    from pathlib import Path

    import altair as alt
    import marimo as mo
    import polars as pl

    from abguard.annotate import annotate
    from abguard.config import MAX_SEQUENCE_LENGTH, ErrorKind
    from abguard.io import READERS, read_table
    from abguard.liabilities import LAP_REFERENCE
    from abguard.pipeline import ValidationError, liability_summary, validate_competition

    # Severity palette, high to low: warm for urgent, cool for informational.
    SEVERITY_ORDER = ["high", "medium", "low"]
    SEVERITY_COLOURS = ["#b4453c", "#c98a3e", "#6f8ea8"]
    REJECT_COLOUR = "#b4453c"

    DEFAULT_INPUT = os.environ.get("ABGUARD_INPUT", "")
    return (
        DEFAULT_INPUT,
        ErrorKind,
        LAP_REFERENCE,
        MAX_SEQUENCE_LENGTH,
        Path,
        READERS,
        REJECT_COLOUR,
        SEVERITY_COLOURS,
        SEVERITY_ORDER,
        ValidationError,
        alt,
        annotate,
        liability_summary,
        mo,
        pl,
        read_table,
        tempfile,
        validate_competition,
    )


@app.cell
def chart_helper(mo):
    def chart(spec):
        """Render an Altair chart in marimo.

        ``legend_selection`` is left on by default and, with this marimo/Vega
        combination, binds a legend selection that renders every mark fully
        transparent until something is selected -- i.e. an empty chart. Neither
        selection is read anywhere here, so both are off; tooltips still work.
        """
        return mo.ui.altair_chart(spec, chart_selection=False, legend_selection=False)

    return (chart,)


@app.cell
def title(mo):
    mo.md(
        """
        # Liability check

        Hard validation and LAP liability profiling for **VHH**, **scFv** and
        **paired antibody** design submissions.

        Liabilities follow the *Antibody Liability Reference* of
        [Satława et al. 2024, PLOS Comput Biol 20(3):e1011881](https://doi.org/10.1371/journal.pcbi.1011881).
        They are **over-predictive** — the paper finds over 90% of real antibody
        sequences carry at least one — so they are reported here, never used to reject a
        design. Only the hard checks do that.
        """
    )
    return


@app.cell
def input_controls(DEFAULT_INPUT, mo):
    path_input = mo.ui.text(
        value=DEFAULT_INPUT,
        label="Submission file or folder",
        placeholder="examples/teams",
        full_width=True,
    )
    upload = mo.ui.file(
        label="…or upload a table",
        filetypes=[".csv", ".tsv", ".json", ".ndjson", ".parquet"],
    )
    mo.vstack([path_input, upload])
    return path_input, upload


@app.cell
def load(Path, READERS, path_input, pl, read_table, tempfile, upload):
    def load_submissions():
        """Read the selection into one frame, tagging every row with its team.

        A folder is read as one file per team, named by the file stem; a single file
        or an upload is read as a single team. Returns ``(frame, paths)`` with a null
        frame when nothing is selected yet.
        """
        if upload.value:
            name = upload.value[0].name
            target = Path(tempfile.mkdtemp(prefix="abguard-upload-")) / name
            target.write_bytes(upload.value[0].contents)
            frame = read_table(target).with_columns(team=pl.lit(target.stem))
            return frame, [target]

        raw = (path_input.value or "").strip()
        if not raw:
            return None, []
        root = Path(raw).expanduser()
        if not root.exists():
            raise FileNotFoundError(f"{root} does not exist")

        paths = (
            [root]
            if root.is_file()
            else sorted(
                path for path in root.glob("*") if path.is_file() and path.suffix.lower() in READERS
            )
        )
        if not paths:
            raise FileNotFoundError(f"{root} holds no readable submission files")

        frames = [
            read_table(path).cast({"*": pl.String}).with_columns(team=pl.lit(path.stem))
            for path in paths
        ]
        return pl.concat(frames, how="diagonal_relaxed"), paths

    try:
        submissions, source_paths = load_submissions()
        load_error = None
    except Exception as exc:  # shown in the UI rather than crashing the cell
        submissions, source_paths, load_error = None, [], f"{type(exc).__name__}: {exc}"
    return load_error, source_paths, submissions


@app.cell
def load_status(load_error, mo, source_paths, submissions):
    if load_error is not None:
        status = mo.md(f"/// danger | Could not read the input\n\n{load_error}\n///")
    elif submissions is None:
        status = mo.md(
            "/// tip | Point the box above at a submission file, or at a folder "
            "holding one file per team, to begin.\n///"
        )
    else:
        status = mo.md(
            f"Loaded **{submissions.height}** design(s) from **{len(source_paths)}** "
            f"file(s): {', '.join(path.name for path in source_paths)}"
        )
    status
    return


@app.cell
def annotation(annotate, submissions):
    # One annotation pass feeds every panel below. Empty until an input is selected,
    # so the rest of the notebook needs no further guards.
    annotated = None if submissions is None else annotate(submissions)
    has_data = annotated is not None and annotated.height > 0
    return annotated, has_data


@app.cell
def headline(annotated, has_data, mo, pl):
    if not has_data:
        headline_view = mo.md("")
    else:
        n_total = annotated.height
        n_valid = int(annotated["is_valid"].sum())
        n_flagged = annotated.filter(pl.col("is_valid") & (pl.col("n_liabilities") > 0)).height
        headline_view = mo.hstack(
            [
                mo.stat(label="Designs", value=f"{n_total}", bordered=True),
                mo.stat(
                    label="Pass hard checks",
                    value=f"{n_valid}",
                    caption=f"{n_valid / n_total:.0%}",
                    bordered=True,
                ),
                mo.stat(
                    label="Rejected",
                    value=f"{n_total - n_valid}",
                    caption="dropped by --drop, fatal without it",
                    bordered=True,
                ),
                mo.stat(
                    label="Liability hits",
                    value=f"{int(annotated['n_liabilities'].sum())}",
                    caption=f"{n_flagged} valid design(s) carry ≥1",
                    bordered=True,
                ),
                mo.stat(
                    label="High severity",
                    value=f"{int(annotated['n_high_severity'].sum())}",
                    bordered=True,
                ),
            ],
            widths="equal",
            gap=1,
        )
    headline_view
    return


@app.cell
def errors_chart(ErrorKind, REJECT_COLOUR, alt, annotated, chart, has_data, mo):
    if not has_data:
        errors_view = mo.md("")
    else:
        _error_counts = (
            annotated.select("errors")
            .explode("errors")
            .drop_nulls("errors")
            .group_by("errors")
            .len()
            .rename({"errors": "error", "len": "designs"})
            .sort("designs", descending=True)
        )
        if _error_counts.is_empty():
            errors_body = mo.md("/// tip | Every design passes every hard check.\n///")
        else:
            errors_body = chart(
                alt.Chart(_error_counts)
                .mark_bar(color=REJECT_COLOUR, cornerRadiusEnd=3)
                .encode(
                    x=alt.X("designs:Q", title="designs", axis=alt.Axis(tickMinStep=1)),
                    y=alt.Y("error:N", sort="-x", title=None),
                    tooltip=["error:N", "designs:Q"],
                )
                .properties(height=max(90, 28 * _error_counts.height), width="container")
            )
        _untriggered = sorted(set(ErrorKind) - set(_error_counts["error"].to_list()))
        errors_view = mo.vstack(
            [
                mo.md("## Hard validation"),
                errors_body,
                mo.md(
                    "<small>Checks not triggered: "
                    f"{', '.join(_untriggered) or 'none — all of them fired'}</small>"
                ),
            ]
        )
    errors_view
    return


@app.cell
def rejected_table(annotated, has_data, mo, pl):
    if not has_data:
        rejected_view = mo.md("")
    else:
        rejected = annotated.filter(~pl.col("is_valid")).select(
            "team",
            "sequence_id",
            "kind",
            pl.col("errors").list.join(", ").alias("errors"),
            "n_domains",
            pl.col("chain_types").list.join("+").alias("chains"),
            pl.col("heavy_sequence").str.len_chars().alias("heavy_len"),
            pl.col("light_sequence").str.len_chars().alias("light_len"),
            "design_description",
        )
        rejected_view = mo.vstack(
            [
                mo.md("### Rejected designs"),
                mo.ui.table(rejected, selection=None, page_size=10)
                if not rejected.is_empty()
                else mo.md("<small>None.</small>"),
            ]
        )
    rejected_view
    return


@app.cell
def liability_chart(
    SEVERITY_COLOURS,
    SEVERITY_ORDER,
    alt,
    annotated,
    chart,
    has_data,
    liability_summary,
    mo,
    pl,
):
    if not has_data:
        liability_view = mo.md("")
    else:
        _summary = liability_summary(annotated).filter(pl.col("n_occurrences") > 0)
        if _summary.is_empty():
            liability_body = mo.md(
                "/// tip | No liabilities found — unusual enough to be worth "
                "double-checking the input.\n///"
            )
        else:
            liability_body = chart(
                alt.Chart(_summary)
                .mark_bar(cornerRadiusEnd=3)
                .encode(
                    x=alt.X(
                        "n_designs:Q",
                        title="designs affected",
                        axis=alt.Axis(tickMinStep=1),
                    ),
                    y=alt.Y("tag:N", sort="-x", title=None),
                    color=alt.Color(
                        "severity:N",
                        scale=alt.Scale(domain=SEVERITY_ORDER, range=SEVERITY_COLOURS),
                        legend=alt.Legend(title="severity", orient="bottom"),
                    ),
                    tooltip=[
                        "tag:N",
                        "name:N",
                        "severity:N",
                        "n_designs:Q",
                        "n_occurrences:Q",
                    ],
                )
                .properties(height=max(120, 28 * _summary.height), width="container")
            )
        liability_view = mo.vstack([mo.md("## Liability profile"), liability_body])
    liability_view
    return


@app.cell
def hits_frame(annotated, has_data, pl):
    # Every liability occurrence, one row per hit, joined to its design.
    all_hits = (
        annotated.select("team", "sequence_id", "kind", "liabilities")
        .explode("liabilities")
        .drop_nulls("liabilities")
        .unnest("liabilities")
        if has_data
        else pl.DataFrame()
    )
    return (all_hits,)


@app.cell
def hit_filters(LAP_REFERENCE, mo):
    severity_filter = mo.ui.multiselect(
        options=["high", "medium", "low"],
        value=["high", "medium", "low"],
        label="Severity",
    )
    tag_filter = mo.ui.multiselect(
        options=sorted(rule.tag for rule in LAP_REFERENCE),
        value=[],
        label="Liability (empty = all)",
    )
    region_filter = mo.ui.multiselect(
        options=["cdr1", "cdr2", "cdr3", "fr1", "fr2", "fr3", "fr4"],
        value=[],
        label="IMGT region (empty = all)",
    )
    mo.hstack([severity_filter, tag_filter, region_filter], justify="start", gap=2)
    return region_filter, severity_filter, tag_filter


@app.cell
def hits_table(all_hits, mo, pl, region_filter, severity_filter, tag_filter):
    if all_hits.is_empty():
        hits_view = mo.md("")
    else:
        view = all_hits.filter(pl.col("severity").is_in(severity_filter.value))
        if tag_filter.value:
            view = view.filter(pl.col("tag").is_in(tag_filter.value))
        if region_filter.value:
            view = view.filter(pl.col("region").is_in(region_filter.value))
        hits_view = mo.vstack(
            [
                mo.md(f"### Occurrences ({view.height} of {all_hits.height})"),
                mo.ui.table(
                    view.select(
                        "team",
                        "sequence_id",
                        "kind",
                        "tag",
                        "severity",
                        "column",
                        "domain_index",
                        "chain",
                        "region",
                        "motif",
                        pl.col("imgt_positions").list.join(",").alias("imgt"),
                    ),
                    selection=None,
                    page_size=15,
                ),
            ]
        )
    hits_view
    return


@app.cell
def design_selector(annotated, has_data, mo):
    def design_options(frame):
        """Label every row uniquely, mapping each label to its row index.

        Keyed by row rather than by ``sequence_id`` on purpose: a submission with
        duplicate IDs is exactly what this dashboard exists to show, so the picker
        has to survive them. Labels carry the team when more than one is loaded, and
        a row number only where that is still not enough to tell two rows apart.
        """
        multi_team = frame["team"].n_unique() > 1 if "team" in frame.columns else False
        counts = {}
        for row in frame.select("sequence_id", "team").iter_rows(named=True):
            label = (
                f"{row['team']} · {row['sequence_id']}" if multi_team else str(row["sequence_id"])
            )
            counts[label] = counts.get(label, 0) + 1

        options, seen = {}, {}
        for index, row in enumerate(frame.select("sequence_id", "team").iter_rows(named=True)):
            label = (
                f"{row['team']} · {row['sequence_id']}" if multi_team else str(row["sequence_id"])
            )
            if counts[label] > 1:
                seen[label] = seen.get(label, 0) + 1
                label = f"{label}  [row {index + 1}]"
            options[label] = index
        return options

    options = design_options(annotated) if has_data else {}
    design_picker = mo.ui.dropdown(
        options=options,
        value=next(iter(options), None),
        label="Design",
    )
    mo.vstack([mo.md("## Per-design detail"), design_picker]) if has_data else mo.md("")
    return (design_picker,)


@app.cell
def design_detail(MAX_SEQUENCE_LENGTH, annotated, design_picker, has_data, mo):
    def render_design(row):
        """Summary, hard-check verdict and the sequences themselves."""
        confidence = f"{row['min_confidence']:.2f}" if row["min_confidence"] is not None else "n/a"
        header = mo.md(
            f"### {row['sequence_id']} · `{row['kind']}`\n\n"
            f"{row['design_description'] or '_no description_'}\n\n"
            f"**{row['n_domains']}** numbered domain(s)"
            f" ({'+'.join(row['chain_types']) or 'none'}),"
            f" min confidence {confidence}"
        )
        verdict = mo.md(
            "/// tip | Passes every hard check.\n///"
            if row["is_valid"]
            else "/// danger | Rejected: " + ", ".join(row["errors"]) + "\n///"
        )
        blocks = [header, verdict]
        for column, label in (
            ("heavy_sequence", "Heavy chain / construct"),
            ("light_sequence", "Light chain"),
        ):
            sequence = row.get(column)
            if not sequence:
                continue
            flagged = {hit["start"] for hit in row["liabilities"] if hit["column"] == column}
            blocks.append(
                mo.md(
                    f"**{label}** — {len(sequence)} / {MAX_SEQUENCE_LENGTH} residues, "
                    f"{len(flagged)} flagged position(s)\n\n```\n{sequence}\n```"
                )
            )
        return mo.vstack(blocks)

    if not has_data or design_picker.value is None:
        detail_view = mo.md("")
    else:
        detail_view = render_design(annotated.row(design_picker.value, named=True))
    detail_view
    return


@app.cell
def design_hits(annotated, design_picker, has_data, mo, pl):
    # Read the selected row's own liability list rather than filtering `all_hits` by
    # sequence_id, which would be ambiguous when IDs repeat.
    if not has_data or design_picker.value is None:
        design_hits_view = mo.md("")
    else:
        here = pl.DataFrame(
            annotated["liabilities"][design_picker.value].to_list(),
            schema={
                "tag": pl.String,
                "name": pl.String,
                "severity": pl.String,
                "column": pl.String,
                "domain_index": pl.Int32,
                "chain": pl.String,
                "region": pl.String,
                "motif": pl.String,
                "start": pl.Int32,
                "imgt_positions": pl.List(pl.String),
            },
        )
        design_hits_view = (
            mo.ui.table(
                here.select(
                    "tag",
                    "name",
                    "severity",
                    "column",
                    "domain_index",
                    "chain",
                    "region",
                    "motif",
                    pl.col("imgt_positions").list.join(",").alias("imgt"),
                ),
                selection=None,
                page_size=20,
            )
            if not here.is_empty()
            else mo.md("<small>No liabilities in this design.</small>")
        )
    design_hits_view
    return


@app.cell
def competition(Path, ValidationError, mo, path_input, validate_competition):
    def run_competition_check():
        """Cross-team duplicate check — only meaningful for a folder of teams."""
        raw = (path_input.value or "").strip()
        if not raw:
            return mo.md("")
        root = Path(raw).expanduser()
        if not root.is_dir():
            return mo.md(
                "<small>Point the input at a <em>folder</em> of per-team files to run "
                "the cross-team duplicate check.</small>"
            )
        try:
            _, report = validate_competition(root, drop=True)
        except ValidationError as exc:
            return mo.md(f"/// danger | Competition check failed\n\n```\n{exc}\n```\n///")
        return mo.md(
            f"/// tip | {len(report.teams)} team(s), "
            f"{sum(team.n_valid for team in report.teams)} valid design(s), "
            "and no two teams share a construct.\n///"
        )

    mo.vstack([mo.md("## Competition check"), run_competition_check()])
    return


@app.cell
def reference_table(LAP_REFERENCE, mo, pl):
    mo.vstack(
        [
            mo.md("## Liability reference"),
            mo.ui.table(
                pl.DataFrame(
                    [
                        {
                            "tag": rule.tag,
                            "name": rule.name,
                            "severity": rule.severity.value,
                            "scope": rule.scope.value,
                            "motif": rule.motif,
                            "description": rule.description,
                        }
                        for rule in LAP_REFERENCE
                    ]
                ),
                selection=None,
                page_size=13,
            ),
        ]
    )
    return


if __name__ == "__main__":
    app.run()
