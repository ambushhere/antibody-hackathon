"""Reading submission tables in whatever format polars can consume."""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path

import polars as pl
from loguru import logger

__all__ = ["READERS", "SUPPORTED_SUFFIXES", "read_table", "write_table"]


def _read_json(path: Path) -> pl.DataFrame:
    """Read JSON, accepting both a top-level list and ``{"designs": [...]}``."""
    payload = json.loads(path.read_text())
    if isinstance(payload, dict):
        records = next((value for value in payload.values() if isinstance(value, list)), None)
        if records is None:
            raise ValueError(
                f"{path}: JSON object holds no list of records; expected a list of "
                "designs or an object with one"
            )
        payload = records
    return pl.DataFrame(payload, infer_schema_length=None)


def _separated(separator: str) -> Callable[[Path], pl.DataFrame]:
    def read(path: Path) -> pl.DataFrame:
        return pl.read_csv(path, separator=separator, infer_schema_length=0)

    return read


READERS: dict[str, Callable[[Path], pl.DataFrame]] = {
    ".csv": _separated(","),
    ".tsv": _separated("\t"),
    ".tab": _separated("\t"),
    ".txt": _separated("\t"),
    ".json": _read_json,
    ".ndjson": pl.read_ndjson,
    ".jsonl": pl.read_ndjson,
    ".parquet": pl.read_parquet,
    ".pq": pl.read_parquet,
    ".arrow": pl.read_ipc,
    ".ipc": pl.read_ipc,
    ".feather": pl.read_ipc,
    ".xlsx": pl.read_excel,
    ".avro": pl.read_avro,
}

SUPPORTED_SUFFIXES = tuple(sorted(READERS))


def read_table(path: Path) -> pl.DataFrame:
    """Load a submission table, dispatching on file extension.

    Text formats are read with every column as a string so that a sequence that
    happens to look numeric, or an ID like ``007``, survives intact. Casting to the
    schema's types is dataframely's job.
    """
    reader = READERS.get(path.suffix.lower())
    if reader is None:
        raise ValueError(
            f"{path}: unsupported extension {path.suffix!r}; "
            f"expected one of {', '.join(SUPPORTED_SUFFIXES)}"
        )
    logger.debug("reading {} as {}", path, path.suffix.lower())
    frame = reader(path)
    if frame.is_empty():
        logger.warning("{} holds no rows", path)
    return frame


def write_table(frame: pl.DataFrame, path: Path) -> None:
    """Write `frame` to `path`, dispatching on extension.

    Nested columns (the liability structs) only survive in JSON and parquet, so
    those are the formats the annotation path uses.
    """
    suffix = path.suffix.lower()
    path.parent.mkdir(parents=True, exist_ok=True)
    match suffix:
        case ".json":
            frame.write_json(path)
        case ".ndjson" | ".jsonl":
            frame.write_ndjson(path)
        case ".csv":
            frame.write_csv(path)
        case ".tsv" | ".tab":
            frame.write_csv(path, separator="\t")
        case ".parquet" | ".pq":
            frame.write_parquet(path)
        case _:
            raise ValueError(
                f"{path}: cannot write {suffix!r}; use .json, .ndjson, .csv, .tsv or .parquet"
            )
    logger.info("wrote {} rows to {}", frame.height, path)
