"""Liability and novelty checks for antibody design submission tables.

See :mod:`abguard.schemas` for the accepted table formats, :mod:`abguard.liabilities`
for the LAP Antibody Liability Reference, :mod:`abguard.novelty` for the CDRH3 novelty
gate, and :mod:`abguard.pipeline` for the validation entry points.

:mod:`abguard.reference`, which reads the DuckDB reference database, is deliberately
*not* re-exported here: it imports duckdb, and nothing else in the package needs it, so
importing ``abguard`` should not pay for it. Import it directly when you need it.
"""

from __future__ import annotations

from .annotate import annotate
from .config import Chain, DesignKind, ErrorKind, PipelineConfig
from .liabilities import LAP_REFERENCE, LiabilityHit, LiabilityRule, Severity
from .novelty import (
    IDENTITY_THRESHOLD,
    MUTATIONS_REQUIRED,
    NoveltyClass,
    NoveltyConfig,
    trastuzumab_cdrh3,
    with_novelty,
)
from .pipeline import (
    CompetitionReport,
    SequenceCollision,
    TeamReport,
    ValidationError,
    liability_summary,
    validate_competition,
    validate_file,
    validate_frame,
)
from .schemas import (
    DesignLibrary,
    DesignSchema,
    PairedAntibodySchema,
    ScFvSchema,
    VHHSchema,
)

__version__ = "0.1.0"

__all__ = [
    "IDENTITY_THRESHOLD",
    "LAP_REFERENCE",
    "MUTATIONS_REQUIRED",
    "Chain",
    "CompetitionReport",
    "DesignKind",
    "DesignLibrary",
    "DesignSchema",
    "ErrorKind",
    "LiabilityHit",
    "LiabilityRule",
    "NoveltyClass",
    "NoveltyConfig",
    "PairedAntibodySchema",
    "PipelineConfig",
    "ScFvSchema",
    "SequenceCollision",
    "Severity",
    "TeamReport",
    "VHHSchema",
    "ValidationError",
    "annotate",
    "liability_summary",
    "trastuzumab_cdrh3",
    "validate_competition",
    "validate_file",
    "validate_frame",
    "with_novelty",
]
