"""Validation orchestration for a single team file and for a whole competition."""

from __future__ import annotations

from pathlib import Path

import polars as pl
from loguru import logger
from pydantic import BaseModel, Field

from .annotate import normalize
from .config import DesignKind, PipelineConfig
from .io import read_table
from .liabilities import LAP_REFERENCE
from .novelty import NoveltyConfig, with_novelty
from .schemas import INPUT_COLUMNS, SCHEMA_BY_KIND, DesignLibrary

__all__ = [
    "CompetitionReport",
    "SequenceCollision",
    "TeamReport",
    "ValidationError",
    "construct_key",
    "flatten",
    "liability_summary",
    "validate_competition",
    "validate_file",
    "validate_frame",
]


class ValidationError(Exception):
    """A submission does not satisfy the schema and ``--drop`` was not given."""


class KindReport(BaseModel):
    """Per-format outcome of validating one team's table."""

    kind: DesignKind
    n_input: int
    n_valid: int
    rule_failures: dict[str, int] = Field(
        default_factory=dict, description="dataframely rule name -> rows that failed it"
    )

    @property
    def n_invalid(self) -> int:
        return self.n_input - self.n_valid


class TeamReport(BaseModel):
    """Outcome of validating one team's table."""

    source: Path
    team: str
    n_input: int
    n_valid: int
    kinds: list[KindReport] = Field(default_factory=list)
    unknown_kinds: dict[str, int] = Field(
        default_factory=dict, description="values of `kind` that match no schema"
    )
    duplicate_ids: list[str] = Field(
        default_factory=list, description="sequence_ids used more than once in the file"
    )
    duplicate_constructs: list[str] = Field(
        default_factory=list,
        description="sequence_ids whose heavy/light pair repeats within the file",
    )
    novelty_failures: dict[str, str] = Field(
        default_factory=dict,
        description="sequence_id -> why the novelty gate rejected it; empty when no "
        "reference database was supplied",
    )

    @property
    def n_invalid(self) -> int:
        return self.n_input - self.n_valid

    @property
    def is_clean(self) -> bool:
        return (
            self.n_invalid == 0
            and not self.unknown_kinds
            and not self.duplicate_ids
            and not self.duplicate_constructs
            and not self.novelty_failures
        )

    def problems(self) -> list[str]:
        """Human-readable reasons this submission is not clean."""
        issues: list[str] = []
        for value, count in sorted(self.unknown_kinds.items()):
            issues.append(f"{count} row(s) have unknown kind {value!r}")
        if self.duplicate_ids:
            issues.append(f"duplicate sequence_id: {', '.join(self.duplicate_ids)}")
        if self.duplicate_constructs:
            issues.append(
                f"repeated heavy/light pair for sequence_id: {', '.join(self.duplicate_constructs)}"
            )
        for kind in self.kinds:
            for rule, count in sorted(kind.rule_failures.items(), key=lambda it: -it[1]):
                issues.append(f"[{kind.kind.value}] {rule}: {count} row(s)")
        for sequence_id, reason in sorted(self.novelty_failures.items()):
            issues.append(f"[novelty] {sequence_id}: {reason}")
        return issues


class SequenceCollision(BaseModel):
    """One construct submitted by more than one team."""

    heavy_sequence: str
    light_sequence: str | None
    submissions: dict[str, list[str]] = Field(
        description="team -> the sequence_ids that team used for this construct"
    )

    @property
    def teams(self) -> list[str]:
        return sorted(self.submissions)


class CompetitionReport(BaseModel):
    """Outcome of validating every team's table in a folder."""

    root: Path
    teams: list[TeamReport] = Field(default_factory=list)
    collisions: list[SequenceCollision] = Field(default_factory=list)

    @property
    def is_clean(self) -> bool:
        return not self.collisions and all(team.is_clean for team in self.teams)


def construct_key(frame: pl.DataFrame, *, include_kind: bool = False) -> pl.Expr:
    """An expression identifying a design by its sequence content.

    Two rows share a key exactly when they encode the same chains, regardless of
    ``sequence_id`` or description.

    `include_kind` distinguishes the two users of this key. Within one file it is
    true: submitting the same Fv as both a ``paired`` antibody and an ``scfv`` is a
    legitimate pair of designs, while the same molecule twice under two IDs is a
    mistake. Across teams it is false: identical sequences are a collision whatever
    format they are wrapped in.
    """
    light = (
        pl.col("light_sequence").fill_null("") if "light_sequence" in frame.columns else pl.lit("")
    )
    key = pl.col("heavy_sequence").fill_null("") + pl.lit("/") + light
    if include_kind:
        key = pl.col("kind").fill_null("") + pl.lit("/") + key
    return key


def flatten(library: DesignLibrary) -> pl.DataFrame:
    """Collect every populated member of `library` back into one table.

    Each member types ``kind`` as a single-valued ``Enum``, which have no common
    supertype, so it is cast back to ``String`` before concatenating.
    """
    members = [
        member.collect().with_columns(pl.col("kind").cast(pl.String))
        for member in library.to_dict().values()
        if member is not None
    ]
    if not members:
        return pl.DataFrame(schema={column: pl.String for column in INPUT_COLUMNS})
    return pl.concat(members, how="diagonal_relaxed")


def _check_columns(frame: pl.DataFrame, source: Path) -> pl.DataFrame:
    """Ensure every expected column exists, adding a null ``light_sequence`` if absent."""
    missing = [column for column in INPUT_COLUMNS if column not in frame.columns]
    if missing == ["light_sequence"]:
        logger.debug("{}: no light_sequence column; treating as all-VHH", source)
        return frame.with_columns(light_sequence=pl.lit(None, dtype=pl.String))
    if missing:
        raise ValidationError(
            f"{source}: missing required column(s) {', '.join(missing)}; "
            f"expected {', '.join(INPUT_COLUMNS)}"
        )
    return frame


def _apply_novelty_gate(
    members: dict[str, pl.LazyFrame],
    report: TeamReport,
    *,
    reference: pl.LazyFrame,
    config: PipelineConfig | None,
    novelty: NoveltyConfig | None,
) -> dict[str, pl.LazyFrame]:
    """Drop designs that fail the novelty gate, recording why in `report`.

    Runs after schema validation rather than as a dataframely rule: a rule is a pure
    expression over the row, and this check needs the reference database. Only rows
    that already satisfy the schema are graded, so a design is never reported as
    unoriginal when the real problem is that it could not be numbered.
    """
    kind_reports = {kind.kind.value: kind for kind in report.kinds}
    for kind_value, member in list(members.items()):
        columns = member.collect_schema().names()
        graded = with_novelty(member, reference=reference, config=config, novelty=novelty).collect()
        failed = graded.filter(~pl.col("is_novel_enough"))
        if failed.is_empty():
            continue
        for sequence_id, reason in failed.select("sequence_id", "novelty_reason").iter_rows():
            report.novelty_failures[sequence_id] = reason
        members[kind_value] = graded.filter(pl.col("is_novel_enough")).select(columns).lazy()
        report.n_valid -= failed.height
        if kind_value in kind_reports:
            kind_reports[kind_value].n_valid -= failed.height
    return members


def validate_frame(
    frame: pl.DataFrame,
    *,
    source: Path,
    team: str,
    config: PipelineConfig | None = None,
    drop: bool = False,
    reference: pl.LazyFrame | None = None,
    novelty: NoveltyConfig | None = None,
) -> tuple[DesignLibrary, TeamReport]:
    """Validate one submission table against the compound schema.

    The table is normalized, split on ``kind``, and each partition is validated
    against its own dataframely schema. Non-compliant rows are always identified;
    `drop` decides whether they are discarded or the call fails.

    Args:
        frame: the raw table as read from disk.
        source: path the frame came from, for messages.
        team: team name, for messages and the competition report.
        config: pipeline configuration.
        drop: discard non-compliant rows instead of raising.
        reference: reference CDRH3s from
            :func:`~abguard.reference.cdrh3_reference`. When given, the novelty gate
            runs on top of the schema and a design too close to trastuzumab or to a
            known CDRH3 is rejected. When None the gate is skipped entirely -- see
            :func:`~abguard.annotate.with_novelty_errors`.
        novelty: novelty thresholds.

    Returns:
        The validated :class:`~abguard.schemas.DesignLibrary` and a
        :class:`TeamReport`.

    Raises:
        ValidationError: if the table is non-compliant and `drop` is false, or if a
            required column is missing (which `drop` cannot repair).
    """
    config = config or PipelineConfig()
    frame = normalize(_check_columns(frame, source))

    report = TeamReport(source=source, team=team, n_input=frame.height, n_valid=0)

    known = {kind.value for kind in DesignKind}
    report.unknown_kinds = dict(
        frame.filter(~pl.col("kind").is_in(known))
        .group_by("kind")
        .len()
        .select(pl.col("kind").fill_null("<null>"), "len")
        .iter_rows()
    )

    # sequence_id must be unique across the whole file, not just within one kind,
    # so it is checked here rather than relying on each member's primary key.
    report.duplicate_ids = sorted(
        frame.filter(pl.col("sequence_id").is_duplicated())["sequence_id"]
        .unique()
        .drop_nulls()
        .to_list()
    )
    report.duplicate_constructs = sorted(
        frame.with_columns(_key=construct_key(frame, include_kind=True))
        .filter(pl.col("_key").is_duplicated())["sequence_id"]
        .drop_nulls()
        .to_list()
    )

    members: dict[str, pl.LazyFrame] = {}
    for kind, schema in SCHEMA_BY_KIND.items():
        partition = frame.filter(pl.col("kind") == kind.value)
        if partition.is_empty():
            continue
        result = schema.filter(partition, cast=True)
        valid = result.result
        members[kind.value] = valid.lazy()
        report.kinds.append(
            KindReport(
                kind=kind,
                n_input=partition.height,
                n_valid=valid.height,
                rule_failures=result.failure.counts(),
            )
        )
        report.n_valid += valid.height

    if reference is not None:
        members = _apply_novelty_gate(
            members, report, reference=reference, config=config, novelty=novelty
        )

    if not drop and not report.is_clean:
        raise ValidationError(
            f"{source}: submission is not compliant "
            f"({report.n_valid} of {report.n_input} row(s) pass the schema). "
            "Re-run with --drop to discard the offending rows.\n  - "
            + "\n  - ".join(report.problems())
        )

    if (
        report.duplicate_ids
        or report.duplicate_constructs
        or report.unknown_kinds
        or report.novelty_failures
    ):
        logger.warning("{}: dropped rows for {}", source, "; ".join(report.problems()))

    library = DesignLibrary.validate(members, cast=True)
    return library, report


def validate_file(
    path: Path,
    *,
    config: PipelineConfig | None = None,
    drop: bool = False,
    team: str | None = None,
    reference: pl.LazyFrame | None = None,
    novelty: NoveltyConfig | None = None,
) -> tuple[DesignLibrary, TeamReport]:
    """Read and validate a single submission file. See :func:`validate_frame`."""
    return validate_frame(
        read_table(path),
        source=path,
        team=team or path.stem,
        config=config,
        drop=drop,
        reference=reference,
        novelty=novelty,
    )


def _collisions(frames: dict[str, pl.DataFrame]) -> list[SequenceCollision]:
    """Find constructs submitted by more than one team."""
    if not frames:
        return []
    stacked = pl.concat(
        [
            frame.select(
                pl.lit(team).alias("team"),
                "sequence_id",
                "heavy_sequence",
                "light_sequence",
                _key=construct_key(frame),
            )
            for team, frame in frames.items()
        ],
        how="vertical_relaxed",
    )
    shared = (
        stacked.group_by("_key")
        .agg(pl.col("team").n_unique().alias("n_teams"))
        .filter(pl.col("n_teams") > 1)
    )
    if shared.is_empty():
        return []

    collisions: list[SequenceCollision] = []
    for _, group in stacked.join(shared, on="_key").group_by(["_key"]):
        submissions: dict[str, list[str]] = {}
        for team, sequence_id in group.select("team", "sequence_id").iter_rows():
            submissions.setdefault(team, []).append(sequence_id)
        first = group.row(0, named=True)
        collisions.append(
            SequenceCollision(
                heavy_sequence=first["heavy_sequence"],
                light_sequence=first["light_sequence"],
                submissions={team: sorted(ids) for team, ids in submissions.items()},
            )
        )
    return sorted(collisions, key=lambda collision: collision.heavy_sequence)


def validate_competition(
    root: Path,
    *,
    config: PipelineConfig | None = None,
    drop: bool = False,
    pattern: str = "*",
    reference: pl.LazyFrame | None = None,
    novelty: NoveltyConfig | None = None,
) -> tuple[dict[str, DesignLibrary], CompetitionReport]:
    """Validate every team file in `root` and check for cross-team duplicates.

    One file is one team; the team name is the file stem. Each file is validated on
    its own exactly as ``team-validate`` would, then the surviving designs are
    compared across teams: a construct (heavy plus light sequence) submitted by two
    different teams is always an error, which `drop` does not suppress.

    Args:
        root: folder holding one submission file per team.
        config: pipeline configuration.
        drop: discard non-compliant rows within each file instead of raising.
        pattern: glob selecting the submission files.
        reference: reference CDRH3s enabling the novelty gate; see
            :func:`validate_frame`.
        novelty: novelty thresholds.

    Returns:
        The validated library per team, and a :class:`CompetitionReport`.

    Raises:
        ValidationError: if `root` holds no readable submissions, if a file is
            non-compliant and `drop` is false, or if two teams share a construct.
    """
    from .io import READERS

    if not root.is_dir():
        raise ValidationError(f"{root} is not a directory")

    paths = sorted(
        path for path in root.glob(pattern) if path.is_file() and path.suffix.lower() in READERS
    )
    if not paths:
        raise ValidationError(
            f"{root}: no submission files matching {pattern!r} with a supported extension"
        )

    report = CompetitionReport(root=root)
    libraries: dict[str, DesignLibrary] = {}
    frames: dict[str, pl.DataFrame] = {}
    failures: list[str] = []

    for path in paths:
        team = path.stem
        if team in libraries:
            raise ValidationError(
                f"{path}: two files share the team name {team!r}; team names come from "
                "file stems and must be unique"
            )
        logger.info("validating team {} from {}", team, path.name)
        try:
            library, team_report = validate_frame(
                read_table(path),
                source=path,
                team=team,
                config=config,
                drop=drop,
                reference=reference,
                novelty=novelty,
            )
        except ValidationError as error:
            failures.append(str(error))
            continue
        libraries[team] = library
        report.teams.append(team_report)
        designs = flatten(library)
        if not designs.is_empty():
            frames[team] = designs

    if failures:
        raise ValidationError("\n".join(failures))

    report.collisions = _collisions(frames)
    if report.collisions:
        lines = [
            f"{' and '.join(collision.teams)} both submitted "
            + ", ".join(
                f"{team}:{'/'.join(ids)}" for team, ids in sorted(collision.submissions.items())
            )
            + f" (heavy {collision.heavy_sequence[:24]}...)"
            for collision in report.collisions
        ]
        raise ValidationError(
            f"{len(report.collisions)} construct(s) submitted by more than one team:\n  - "
            + "\n  - ".join(lines)
        )

    return libraries, report


def liability_summary(annotated: pl.DataFrame) -> pl.DataFrame:
    """Count rows and occurrences per LAP tag in an annotated table.

    Args:
        annotated: output of :func:`~abguard.annotate.annotate` with liabilities on.

    Returns:
        One row per LAP tag, with ``n_occurrences`` (total hits) and ``n_designs``
        (designs carrying at least one), ordered by severity then occurrences.
        Tags that never fire are included with zero counts.
    """
    exploded = (
        annotated.select("sequence_id", "liabilities")
        .explode("liabilities")
        .drop_nulls("liabilities")
        .unnest("liabilities")
    )
    reference = pl.DataFrame(
        {
            "tag": [rule.tag for rule in LAP_REFERENCE],
            "name": [rule.name for rule in LAP_REFERENCE],
            "severity": [rule.severity.value for rule in LAP_REFERENCE],
        }
    )
    if exploded.is_empty():
        counts = reference.select(
            "tag", n_occurrences=pl.lit(0, pl.UInt32), n_designs=pl.lit(0, pl.UInt32)
        )
    else:
        counts = exploded.group_by("tag").agg(
            n_occurrences=pl.len(),
            n_designs=pl.col("sequence_id").n_unique(),
        )
    severity_order = {"high": 0, "medium": 1, "low": 2}
    return (
        reference.join(counts, on="tag", how="left")
        .with_columns(
            pl.col("n_occurrences", "n_designs").fill_null(0),
            _order=pl.col("severity").replace_strict(severity_order, return_dtype=pl.Int8),
        )
        .sort(["_order", "n_occurrences"], descending=[False, True])
        .drop("_order")
    )
