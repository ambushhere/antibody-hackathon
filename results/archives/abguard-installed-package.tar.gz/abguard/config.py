"""Typed configuration for the liability pipeline."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field

#: The 20 canonical proteinogenic amino acids, single-letter code.
CANONICAL_AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"

#: Regex a sequence column must match to be a valid amino acid string.
AMINO_ACID_REGEX = rf"^[{CANONICAL_AMINO_ACIDS}]+$"

#: Hard cap on the length of any single submitted polypeptide, in residues.
#:
#: This is a competition rule and is deliberately not configurable: dataframely
#: column checks are declared on the schema class, so a runtime override would apply
#: to the annotation path but not to validation, which is worse than no knob at all.
#: It is sized for the scFv case -- a VH-linker-VL construct runs to about 240.
MAX_SEQUENCE_LENGTH = 250

#: IMGT positions of the two canonical intra-domain cysteines.
CANONICAL_CYSTEINE_POSITIONS = ("23", "104")

#: Minimum immunum alignment confidence for a domain to count as numbered.
#:
#: A module constant for the same reason as :data:`MAX_SEQUENCE_LENGTH`: the dataframely
#: rules in :mod:`abguard.schemas` are declared on the class and cannot read runtime
#: config, so the validation path has to take this value from here. It is also the
#: default of :attr:`PipelineConfig.min_confidence`, which is what the reporting path
#: and the novelty gate use -- the two must agree, or a design numbers for one and not
#: the other.
#:
#: Set low on purpose. Raising it does not make numbering safer, it just discards real
#: antibodies: on the 2,306 nanobodies of plabdab_nano, 0.5 numbers 1,963 and rejects
#: 343 as `low_confidence`, while 0.1 numbers 2,246. A non-antibody is still rejected at
#: 0.1 -- immunum reports `domain_too_short` instead of `low_confidence`, and both set
#: `error_kind`, which is what the checks actually read.
MIN_CONFIDENCE = 0.1


class DesignKind(StrEnum):
    """The molecule formats a team may submit."""

    VHH = "vhh"
    SCFV = "scfv"
    PAIRED = "paired"


class Chain(StrEnum):
    """Which chain of a design a value belongs to."""

    HEAVY = "heavy"
    LIGHT = "light"


#: Chain groups used when numbering a column without assuming the submission's kind,
#: i.e. for annotation and the dashboard. ``"ig"`` covers IGH, IGK and IGL.
#:
#: Every check numbers with this and then inspects the ``chain`` immunum assigned,
#: rather than restricting the chain set up front. The difference matters: asked to
#: choose among IGH/IGK/IGL, immunum labels trastuzumab's VH as ``H`` at 0.88 and its
#: VL as ``K`` at 0.88, and those labels do not move with
#: :data:`MIN_CONFIDENCE`, because the choice is relative. Restricted to ``["h"]`` it
#: has no alternative to offer and force-fits the light chain as ``H`` at 0.11, so the
#: confidence floor is the only thing rejecting it -- which makes chain identification
#: a side effect of a threshold tuned for something else. Checking the label is both
#: explicit and independent of the floor.
ANY_IG = ["ig"]

#: The ``chain`` values ``number_domains`` reports for each immunum chain selector.
CHAIN_LABELS: dict[str, tuple[str, ...]] = {
    "h": ("H",),
    "k": ("K",),
    "l": ("L",),
    "ig": ("H", "K", "L"),
}


class DomainSpec(BaseModel):
    """How many variable domains a column must hold, and of which chains.

    ``vhh`` and ``scfv`` are both a single polypeptide submitted in
    ``heavy_sequence``; they differ in how many domains immunum must find in it (one
    for a VHH, two for an scFv's VH and VL). ``paired`` submits its two domains in
    two columns. A column with no spec for a kind must be null for that kind.
    """

    model_config = {"frozen": True}

    n_domains: int = Field(ge=1, description="exact number of domains immunum must find")
    chains: list[str] = Field(
        description="immunum chain names/groups the domains must be drawn from"
    )

    @property
    def labels(self) -> list[str]:
        """The ``chain`` values a domain satisfying this spec may carry.

        ``["ig"]`` expands to all three, i.e. unconstrained -- which is what ``scfv``
        wants, since either VH-VL orientation is accepted.
        """
        return sorted({label for chain in self.chains for label in CHAIN_LABELS[chain]})


#: Per-kind expectation for each sequence column. A column absent from a kind's entry
#: must be null for that kind.
DOMAIN_SPEC: dict[DesignKind, dict[Chain, DomainSpec]] = {}


class ErrorKind(StrEnum):
    """Hard-validation failure kinds, reported in the ``errors`` column.

    These are exactly the checks that gate validation: a row with any of them is
    non-compliant and is either dropped (``--drop``) or fails the run.
    """

    INVALID_AMINO_ACIDS = "invalid_amino_acids"
    SEQUENCE_TOO_LONG = "sequence_too_long"
    UNPAIRED_CYSTEINE = "unpaired_cysteine"
    NUMBERING_FAILED = "numbering_failed"
    WRONG_DOMAIN_COUNT = "wrong_domain_count"
    MISSING_SEQUENCE = "missing_sequence"
    UNEXPECTED_SEQUENCE = "unexpected_sequence"
    DUPLICATE_SEQUENCE_ID = "duplicate_sequence_id"
    UNKNOWN_KIND = "unknown_kind"
    #: The design's CDRH3 is too close to trastuzumab's or to a known CDRH3. Unlike
    #: every other kind here this one is not decided by the row alone: it needs the
    #: reference database, so it only fires when one is supplied. See
    #: :mod:`abguard.novelty`.
    INSUFFICIENT_CDRH3_NOVELTY = "insufficient_cdrh3_novelty"


class PipelineConfig(BaseModel):
    """Knobs for numbering and the hard checks.

    The defaults are the competition rules; the CLI only exposes ``scheme`` and
    ``max_sequence_length``, the rest exist so tests and the dashboard can relax
    individual checks.
    """

    model_config = {"frozen": True}

    scheme: str = Field(default="imgt", description="immunum numbering scheme")
    min_confidence: float = Field(
        default=MIN_CONFIDENCE,
        ge=0.0,
        le=1.0,
        description="minimum immunum alignment confidence; the default is the "
        "competition rule and is what abguard.schemas validates against",
    )
    cdr_flank: int = Field(
        default=1,
        ge=0,
        description=(
            "residues of framework on each side of a CDR that count as part of it when "
            "matching CDR-scoped liability motifs (LAP uses 1)"
        ),
    )


DOMAIN_SPEC.update(
    {
        # A VHH is one heavy-chain variable domain and nothing else.
        DesignKind.VHH: {Chain.HEAVY: DomainSpec(n_domains=1, chains=["h"])},
        # An scFv is one polypeptide holding two variable domains joined by a linker.
        # Either orientation (VH-VL or VL-VH) is accepted, so the chains are unconstrained.
        DesignKind.SCFV: {Chain.HEAVY: DomainSpec(n_domains=2, chains=ANY_IG)},
        # A paired antibody submits its heavy and light domains in separate columns.
        DesignKind.PAIRED: {
            Chain.HEAVY: DomainSpec(n_domains=1, chains=["h"]),
            Chain.LIGHT: DomainSpec(n_domains=1, chains=["k", "l"]),
        },
    }
)


def sequence_column(chain: Chain) -> str:
    """Name of the input column holding `chain`."""
    return f"{chain.value}_sequence"
