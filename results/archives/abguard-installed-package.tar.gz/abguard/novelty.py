"""The novelty gate: how far a design must sit from trastuzumab and from prior art.

A submission to a HER2 competition is graded against trastuzumab, the clinical
anti-HER2 antibody, in two steps.

**Step 1 -- how trastuzumab-like is it?** The design's variable domains are compared
with trastuzumab's, giving a sequence identity that splits submissions in two:

==========  ==============================  =====================================
class       identity to trastuzumab         what it is
==========  ==============================  =====================================
``novel``   >= :data:`IDENTITY_THRESHOLD`   an engineered trastuzumab variant
``de_novo`` < :data:`IDENTITY_THRESHOLD`    a different molecule altogether
==========  ==============================  =====================================

Identity pools the edit distances and the lengths over the chains the design
actually has, rather than averaging per-chain percentages::

    identity = 1 - (d_H + d_L) / (max(|VH|, |ref VH|) + max(|VL|, |ref VL|))

A ``vhh`` has no light chain, so only the heavy terms appear and its identity is
decided entirely by its VH -- the light reference must not be charged against it,
or every VHH would look 20 points more trastuzumab-like than it is. For ``scfv``
and ``paired`` both chains count, weighted by their length, so swapping in a
foreign VL moves the identity as much as the chain's size warrants.

**Step 2 -- is its CDRH3 new?** CDRH3 is where an antibody's specificity mostly
lives, so a design is only new if its CDRH3 is new. The gate asks for a minimum
number of mutations from *every* CDRH3 already known -- trastuzumab's own, plus
every CDRH3 in the reference database -- and the bar depends on step 1:

==========  =======================================  ==========================
class       mutations required in CDRH3              rationale
==========  =======================================  ==========================
``novel``   :data:`MUTATIONS_REQUIRED`\\ [novel]      the only place it differs
``de_novo`` :data:`MUTATIONS_REQUIRED`\\ [de_novo]    already distant elsewhere
==========  =======================================  ==========================

A ``novel`` design sits on trastuzumab's framework, so its CDRH3 is the only thing
that makes it a new molecule and the bar is higher. A ``de_novo`` design is already
far from trastuzumab everywhere, so a lower CDRH3 bar still leaves it distinct.

Both steps read their regions from immunum's IMGT segmentation, which is the single
source of truth for where a CDR starts and ends. That matters for the reference
data too: a table of CDRH3s carries whatever the depositor chose to call a CDRH3,
which is not necessarily the IMGT region. Trastuzumab's IMGT CDRH3 is the 13-mer
``SRWGGDGFYAMDY``, while the HER2 assay tables name its 10-mer core
``WGGDGFYAMD``; comparing a design's IMGT CDR3 against those cores would hand every
design three free mutations from the flanks alone. So
:func:`~abguard.reference.cdrh3_from_sequences` re-derives the IMGT CDR3 of every
reference entry from its full sequence, and both sides of every distance here are
immunum IMGT regions.

Distances are Levenshtein, computed with ``polars-distance``: CDRH3 length varies
between antibodies, so an indel has to count as one mutation rather than
invalidating the comparison. On the equal-length CDRH3s of the HER2 libraries it
agrees exactly with the ``edit_distance`` column those tables ship.
"""

from __future__ import annotations

from collections.abc import Callable
from enum import StrEnum
from functools import cache

import immunum.polars as imp
import polars as pl
import polars_distance as pld
from pydantic import BaseModel, Field

from .config import ANY_IG, Chain, PipelineConfig, sequence_column

__all__ = [
    "IDENTITY_THRESHOLD",
    "MUTATIONS_REQUIRED",
    "NOVELTY_COLUMNS",
    "TRASTUZUMAB_VH",
    "TRASTUZUMAB_VL",
    "NoveltyClass",
    "NoveltyConfig",
    "trastuzumab_cdrh3",
    "trastuzumab_reference",
    "with_cdrh3",
    "with_novelty",
]

#: Trastuzumab's variable domains (DrugBank DB00072), the reference every design is
#: graded against.
#:
#: Duplicated from ``examples/make_examples.py`` on purpose: the examples folder is a
#: development aid and is not shipped in the wheel, so the package cannot import it.
TRASTUZUMAB_VH = (
    "EVQLVESGGGLVQPGGSLRLSCAASGFNIKDTYIHWVRQAPGKGLEWVARIYPTNGYTRYADSVKGRFTISADTSKNT"
    "AYLQMNSLRAEDTAVYYCSRWGGDGFYAMDYWGQGTLVTVSS"
)
TRASTUZUMAB_VL = (
    "DIQMTQSPSSLSASVGDRVTITCRASQDVNTAVAWYQQKPGKAPKLLIYSASFLYSGVPSRFSGSRSGTDFTLTISSL"
    "QPEDFATYYCQQHYTTPPTFGQGTKVEIK"
)

#: Identity to trastuzumab at or above which a design is an engineered variant of it
#: rather than its own molecule. Two unrelated human variable domains already share
#: their framework and run 50-65% identical, so the line sits above that band.
IDENTITY_THRESHOLD = 0.70

#: The IMGT regions that make up a numbered variable domain, in sequence order.
#: ``prefix`` and ``postfix`` are excluded, which is what makes identity blind to an
#: scFv linker or a terminal purification tag.
FV_REGIONS = ("fr1", "cdr1", "fr2", "cdr2", "fr3", "cdr3", "fr4")

#: Columns :func:`with_novelty` adds.
NOVELTY_COLUMNS = (
    "cdrh3",
    "cdrh3_confidence",
    "identity_to_trastuzumab",
    "novelty_class",
    "required_cdrh3_mutations",
    "cdrh3_min_distance",
    "cdrh3_nearest",
    "cdrh3_nearest_source",
    "cdrh3_nearest_id",
    "is_novel_enough",
    "novelty_reason",
)

#: What the reference label is for trastuzumab's own CDRH3.
TRASTUZUMAB_SOURCE = "trastuzumab"

#: Columns a CDRH3 reference frame must provide. ``id`` is optional: it names the entry
#: a loop came from, which assay tables do not have and older bundles did not carry.
REFERENCE_COLUMNS = ("cdrh3", "source")


class NoveltyClass(StrEnum):
    """Which novelty regime a design is graded under."""

    #: At or above :data:`IDENTITY_THRESHOLD` identity: a trastuzumab variant.
    NOVEL = "novel"
    #: Below it: a molecule of its own.
    DE_NOVO = "de_novo"


#: Minimum CDRH3 mutations a passing design needs, per class. Not configurable
#: through the CLI: these are the competition's rules, and a submission has to be
#: judged by the same numbers everywhere.
MUTATIONS_REQUIRED: dict[NoveltyClass, int] = {
    NoveltyClass.NOVEL: 3,
    NoveltyClass.DE_NOVO: 2,
}


class NoveltyConfig(BaseModel):
    """Knobs for the novelty gate. The defaults are the competition rules."""

    model_config = {"frozen": True}

    identity_threshold: float = Field(
        default=IDENTITY_THRESHOLD,
        ge=0.0,
        le=1.0,
        description="identity to trastuzumab at or above which a design is `novel`",
    )
    mutations_required: dict[NoveltyClass, int] = Field(
        default_factory=lambda: dict(MUTATIONS_REQUIRED),
        description="minimum CDRH3 mutations per novelty class",
    )

    def required(self, novelty: NoveltyClass) -> int:
        return self.mutations_required[novelty]


def _numbering_kwargs(config: PipelineConfig) -> dict[str, object]:
    """immunum settings, kind-agnostic: every column is numbered as any Ig chain."""
    return {
        "chains": ANY_IG,
        "scheme": config.scheme,
        "min_confidence": config.min_confidence,
    }


@cache
def _reference_fv(sequence: str, chains: tuple[str, ...]) -> tuple[str, str]:
    """The numbered Fv of `sequence` and its IMGT CDR3, as immunum reads them.

    Derived rather than written down, so the reference is segmented by exactly the
    code that segments a submission: if immunum's boundaries move, both sides move
    together and the gate stays self-consistent.
    """
    frame = pl.LazyFrame({"sequence": [sequence]}).with_columns(
        _segments=imp.segment_domains("sequence", chains=list(chains), scheme="imgt")
    )
    segments = frame.collect()["_segments"].to_list()[0]
    if not segments or segments[0].get("error_kind") is not None:
        raise ValueError(f"immunum could not number the reference sequence {sequence[:24]}...")
    first = segments[0]
    return "".join(first[region] or "" for region in FV_REGIONS), first["cdr3"]


def trastuzumab_cdrh3() -> str:
    """Trastuzumab's IMGT CDRH3 (``SRWGGDGFYAMDY``), as immunum segments it."""
    return _reference_fv(TRASTUZUMAB_VH, tuple(ANY_IG))[1]


def trastuzumab_reference() -> pl.LazyFrame:
    """The one-row CDRH3 reference every run includes, with or without a database.

    The rule is "at least N mutations from trastuzumab *and* from anything in the
    database", so trastuzumab's own CDRH3 is simply another reference row and the two
    halves of that sentence collapse into one minimum.
    """
    return pl.LazyFrame(
        {"cdrh3": [trastuzumab_cdrh3()], "source": [TRASTUZUMAB_SOURCE], "id": [None]},
        schema={"cdrh3": pl.String, "source": pl.String, "id": pl.String},
    )


def _sequence_columns(frame: pl.LazyFrame) -> list[str]:
    """The sequence columns `frame` actually has, heavy first."""
    schema = frame.collect_schema()
    return [sequence_column(chain) for chain in Chain if sequence_column(chain) in schema]


def _as_strings(frame: pl.LazyFrame, columns: list[str]) -> pl.LazyFrame:
    """Cast `columns` to ``String``.

    A submission of VHHs only has an empty ``light_sequence``, which polars types as
    ``Null`` rather than ``String``; immunum's plugin rejects that dtype outright.
    :func:`~abguard.annotate.normalize` casts for the same reason, but
    :func:`with_novelty` is callable on a raw table, so it cannot rely on that.
    """
    return frame.with_columns([pl.col(column).cast(pl.String) for column in columns])


def _pooled(columns: list[str], build: Callable[[str], pl.Expr]) -> pl.Expr:
    """`build` applied to every sequence column present, pooled into one list.

    Both columns go into one list so the rest of the module can ask for "the heavy
    domain of this design" without caring which column it arrived in: a ``paired``
    design's VL is in ``light_sequence`` and an ``scfv``'s is the second domain of
    ``heavy_sequence``, and pooling makes those the same question.
    """
    if not columns:
        raise ValueError(
            f"no sequence column to number; expected one of "
            f"{', '.join(sequence_column(chain) for chain in Chain)}"
        )
    return pl.concat_list([build(column).fill_null([]) for column in columns])


def _chain_mask(domains: pl.Expr, wanted: tuple[str, ...]) -> pl.Expr:
    """Per-domain flags: is this one of `wanted`, and did it number cleanly?

    A domain immunum could not number is excluded here rather than silently picked:
    its regions are unusable, and the row already fails hard validation with
    ``numbering_failed``.
    """
    return domains.list.eval(
        pl.element().struct.field("chain").is_in(list(wanted))
        & pl.element().struct.field("error_kind").is_null()
    )


def with_cdrh3(frame: pl.LazyFrame, config: PipelineConfig | None = None) -> pl.LazyFrame:
    """Add the design's numbered Fv per chain plus its IMGT CDRH3.

    Adds ``_vh``/``_vl`` (the numbered variable domains, linker and tags stripped), the
    public ``cdrh3``, and ``cdrh3_confidence``. All are null when the design has no such
    domain.
    """
    config = config or PipelineConfig()
    kwargs = _numbering_kwargs(config)
    columns = _sequence_columns(frame)
    frame = _as_strings(frame, columns)
    domains = _pooled(columns, lambda column: imp.number_domains(column, **kwargs))
    segments = _pooled(columns, lambda column: imp.segment_domains(column, **kwargs))

    masks = frame.with_columns(
        _segments=segments,
        _domains=domains,
        _heavy=_chain_mask(domains, ("H",)),
        _light=_chain_mask(domains, ("K", "L")),
    )

    def segment_of(mask: str) -> pl.Expr:
        # `arg_max` on a boolean list is the index of the first true element, so this
        # takes the first domain of the wanted chain in submission order.
        return pl.col("_segments").list.get(pl.col(mask).list.arg_max(), null_on_oob=True)

    def confidence_of(mask: str) -> pl.Expr:
        """How confident immunum was about the domain whose CDRH3 is being graded.

        Worth reporting rather than hiding: with
        :data:`~abguard.config.MIN_CONFIDENCE` at 0.1, a domain can be numbered on a
        weak alignment, and its region boundaries -- so its CDRH3, so its verdict --
        are only as good as that alignment.
        """
        chosen = pl.col("_domains").list.get(pl.col(mask).list.arg_max(), null_on_oob=True)
        return (
            pl.when(pl.col(mask).list.any()).then(chosen.struct.field("confidence")).otherwise(None)
        )

    def fv(mask: str) -> pl.Expr:
        joined = pl.concat_str(
            [segment_of(mask).struct.field(region).fill_null("") for region in FV_REGIONS]
        )
        return pl.when(pl.col(mask).list.any()).then(joined).otherwise(None)

    def cdr3(mask: str) -> pl.Expr:
        return (
            pl.when(pl.col(mask).list.any())
            .then(segment_of(mask).struct.field("cdr3"))
            .otherwise(None)
        )

    return masks.with_columns(
        _vh=fv("_heavy"),
        _vl=fv("_light"),
        cdrh3=cdr3("_heavy"),
        cdrh3_confidence=confidence_of("_heavy"),
    ).drop("_segments", "_domains", "_heavy", "_light")


def _identity_to_trastuzumab() -> pl.Expr:
    """Length-pooled identity of ``_vh``/``_vl`` to trastuzumab's variable domains.

    Each chain contributes an edit distance and a denominator, and a chain the design
    does not have contributes neither -- see the module docstring.
    """
    chains = ((("_vh"), TRASTUZUMAB_VH), (("_vl"), TRASTUZUMAB_VL))
    distances: list[pl.Expr] = []
    denominators: list[pl.Expr] = []
    for column, reference in chains:
        reference_fv = _reference_fv(reference, tuple(ANY_IG))[0]
        distances.append(
            pld.col(column).dist_str.levenshtein(pl.lit(reference_fv)).fill_null(0).cast(pl.Int64)
        )
        denominators.append(
            pl.when(pl.col(column).is_not_null())
            .then(
                pl.max_horizontal(
                    pl.col(column).str.len_chars(), pl.lit(len(reference_fv), dtype=pl.UInt32)
                )
            )
            .otherwise(None)
            .fill_null(0)
            .cast(pl.Int64)
        )
    total = pl.sum_horizontal(denominators)
    # A row with no numbered domain at all has a zero denominator; it has already
    # failed hard validation, and a null identity keeps it out of the class split.
    return pl.when(total > 0).then(1 - pl.sum_horizontal(distances) / total).otherwise(None)


def _nearest(reference: pl.LazyFrame, designs: pl.LazyFrame) -> pl.LazyFrame:
    """For every distinct ``cdrh3`` in `designs`, its closest row in `reference`.

    A cross join rather than a per-design pass: it keeps the whole computation in one
    lazy plan that the streaming engine can run in bounded memory, and polars-distance
    evaluates the Levenshtein column in parallel. Designs are reduced to their
    distinct CDRH3s first, so a submission that varies only outside CDRH3 costs one
    comparison, not one per row.
    """
    queries = designs.select("cdrh3").drop_nulls().unique()
    # The reference columns are renamed rather than left to the join's `_right` suffix,
    # so the expressions below do not depend on polars' default suffixing. `id` is
    # optional: assay tables have no entry identifier, and bundles built before it was
    # carried do not have the column at all.
    has_id = "id" in reference.collect_schema()
    known = reference.select(
        _known="cdrh3",
        _source="source",
        _id=pl.col("id") if has_id else pl.lit(None, dtype=pl.String),
    )
    return (
        queries.join(known, how="cross")
        .with_columns(
            _distance=pld.col("cdrh3").dist_str.levenshtein(pl.col("_known")).cast(pl.UInt32)
        )
        .group_by("cdrh3")
        .agg(
            cdrh3_min_distance=pl.col("_distance").min(),
            cdrh3_nearest=pl.col("_known").sort_by("_distance").first(),
            cdrh3_nearest_source=pl.col("_source").sort_by("_distance").first(),
            cdrh3_nearest_id=pl.col("_id").sort_by("_distance").first(),
        )
    )


def with_novelty(
    frame: pl.LazyFrame,
    *,
    reference: pl.LazyFrame | None = None,
    config: PipelineConfig | None = None,
    novelty: NoveltyConfig | None = None,
) -> pl.LazyFrame:
    """Grade every design in `frame` against trastuzumab and the CDRH3 reference.

    Adds the :data:`NOVELTY_COLUMNS`. Nothing is filtered: ``is_novel_enough`` is the
    verdict and ``novelty_reason`` says why a design failed, which is what the CLI
    reports and what the hard check in :mod:`abguard.annotate` reads.

    Args:
        frame: a submission table, lazily. Needs ``heavy_sequence`` and, for the
            paired format, ``light_sequence``.
        reference: extra CDRH3s to require distance from, as ``cdrh3`` and ``source``
            columns -- normally :func:`~abguard.reference.cdrh3_reference`.
            Trastuzumab's own CDRH3 is always included on top of these, so passing
            None grades against trastuzumab alone.
        config: numbering configuration.
        novelty: the thresholds. Defaults to the competition rules.

    Returns:
        `frame` with the novelty columns appended, still lazy.
    """
    novelty = novelty or NoveltyConfig()
    designs = with_cdrh3(frame, config)

    full_reference = trastuzumab_reference()
    if reference is not None:
        extra = reference.drop_nulls("cdrh3")
        if "id" not in extra.collect_schema():
            extra = extra.with_columns(id=pl.lit(None, dtype=pl.String))
        full_reference = pl.concat(
            [full_reference, extra.select("cdrh3", "source", "id")],
            how="vertical_relaxed",
        )
    # Distinct CDRH3s only: the reference tables hold one row per assayed variant and
    # repeat the same CDRH3 many times, and a minimum does not care how often a
    # sequence occurs. `keep="first"` makes the reported `source` deterministic.
    full_reference = full_reference.unique(subset=["cdrh3"], keep="first", maintain_order=True)

    graded = designs.with_columns(identity_to_trastuzumab=_identity_to_trastuzumab()).with_columns(
        novelty_class=pl.when(pl.col("identity_to_trastuzumab").is_null())
        .then(None)
        .when(pl.col("identity_to_trastuzumab") >= novelty.identity_threshold)
        .then(pl.lit(NoveltyClass.NOVEL.value))
        .otherwise(pl.lit(NoveltyClass.DE_NOVO.value))
    )

    required = pl.lit(None, dtype=pl.UInt32)
    for novelty_class, minimum in novelty.mutations_required.items():
        required = (
            pl.when(pl.col("novelty_class") == novelty_class.value)
            .then(pl.lit(minimum, dtype=pl.UInt32))
            .otherwise(required)
        )
    graded = graded.with_columns(required_cdrh3_mutations=required)

    # `maintain_order="left"`: a submission report is read row by row against the file
    # the team sent, so the join must not permute it.
    graded = graded.join(
        _nearest(full_reference, graded), on="cdrh3", how="left", maintain_order="left"
    )

    # A design that fails the comparison we *did* run is definitively not novel enough,
    # whether or not a database was supplied -- trastuzumab's own CDRH3 is always in the
    # reference. A design that passes it is only known to be novel if the database half
    # of the rule was also applied, so without one the verdict is null, meaning "not
    # checked". Reporting True there would be claiming novelty on evidence never
    # gathered, which is how a published antibody comes back clean.
    clears_the_bar = (
        pl.col("cdrh3").is_not_null()
        & pl.col("required_cdrh3_mutations").is_not_null()
        & (pl.col("cdrh3_min_distance") >= pl.col("required_cdrh3_mutations"))
    )
    checked = reference is not None
    verdict = (
        clears_the_bar
        if checked
        else pl.when(clears_the_bar).then(None).otherwise(False).cast(pl.Boolean)
    )

    collided_with = pl.format(
        "CDRH3 {} is {} mutation(s) from {} in {}; a {} design needs at least {}",
        pl.col("cdrh3"),
        pl.col("cdrh3_min_distance"),
        pl.col("cdrh3_nearest"),
        # "pdb" locates the database; "pdb:7eow_B" locates the record, which is
        # what someone disputing a rejection actually needs.
        pl.when(pl.col("cdrh3_nearest_id").is_not_null())
        .then(
            pl.concat_str(
                pl.col("cdrh3_nearest_source"),
                pl.lit(":"),
                pl.col("cdrh3_nearest_id"),
            )
        )
        .otherwise(pl.col("cdrh3_nearest_source")),
        pl.col("novelty_class"),
        pl.col("required_cdrh3_mutations"),
    )
    not_checked = pl.lit(
        "clears the bar against trastuzumab, but no reference database was supplied, "
        "so prior art was not checked"
    )
    reason = (
        pl.when(pl.col("cdrh3").is_null())
        .then(pl.lit("no IMGT heavy CDR3 could be numbered in this design"))
        .when(clears_the_bar)
        .then(None if checked else not_checked)
        .otherwise(collided_with)
    )

    return graded.with_columns(is_novel_enough=verdict, novelty_reason=reason).drop("_vh", "_vl")
