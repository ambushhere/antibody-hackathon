"""``abguard`` command line interface."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Annotated

import polars as pl
import typer
from loguru import logger

from .annotate import annotate
from .config import PipelineConfig
from .io import SUPPORTED_SUFFIXES, read_table, write_table
from .liabilities import LAP_REFERENCE
from .pipeline import (
    CompetitionReport,
    TeamReport,
    ValidationError,
    flatten,
    liability_summary,
    validate_competition,
    validate_file,
)
from .reference import DEFAULT_COMPRESSION_LEVEL

app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help=(
        "Liability and novelty checks for antibody design submissions.\n\n"
        "Validates VHH, scFv and paired-antibody design tables against a dataframely "
        "schema (IMGT-numberable, valid amino acids, <=250 residues per chain, no "
        "unpaired cysteines, unique IDs) and reports sequence liabilities from the LAP "
        "Antibody Liability Reference (PLOS Comput Biol 2024;20(3):e1011881).\n\n"
        "With --reference-db it also applies the novelty gate: a design must differ from "
        "trastuzumab and from every known CDRH3 by at least 3 mutations in CDRH3 if it is "
        "a trastuzumab variant (>=70% identity), or 2 if it is de novo."
    ),
)

# Shared option types.
DropOption = Annotated[
    bool,
    typer.Option(
        "--drop",
        help="Drop non-compliant rows instead of failing. Without it, any violation "
        "is a hard error.",
    ),
]
AllLiabilitiesOption = Annotated[
    bool,
    typer.Option(
        "--all-liabilities",
        help="Report every LAP liability per design instead of validating. Nothing is "
        "filtered and the output is always JSON.",
    ),
]
OutputOption = Annotated[
    Path | None,
    typer.Option("--output", "-o", help="Write the result here instead of stdout."),
]
VerboseOption = Annotated[bool, typer.Option("--verbose", "-v", help="Log debug detail.")]
ReferenceDbOption = Annotated[
    Path | None,
    typer.Option(
        "--reference-db",
        exists=True,
        help="Reference CDRH3s: either a Parquet bundle directory or a DuckDB database. "
        "Overrides the reference bundled with abguard, which is used by default. "
        "Switches the novelty gate on, so a design whose CDRH3 is too close to "
        "trastuzumab's or to a known CDRH3 is rejected. Build one with "
        "`abguard reference-build`, and ship it with `abguard reference-export`.",
    ),
]


NoNoveltyOption = Annotated[
    bool,
    typer.Option(
        "--no-novelty",
        help="Validate structure and liabilities only, without checking novelty. "
        "Required to run without --reference-db, so that skipping the check is always "
        "something you asked for.",
    ),
]


def _reference(database: Path | None, *, skipped: bool = True) -> pl.LazyFrame | None:
    """Resolve the CDRH3 reference for this run, or None if novelty is not checked.

    Precedence, most explicit first:

    1. `skipped` -- ``--no-novelty`` was passed, so nothing is checked and nothing is
       loaded, whatever else is available.
    2. `database` -- an explicit ``--reference-db`` always wins over the bundled one,
       which may be older or hold less.
    3. the reference shipped in the package, so the usual case needs no flag.
    4. nothing: an error for a validating command, because a design that merely
       clears the trastuzumab comparison is unchecked rather than novel.
    """
    from .reference import bundled_reference, cdrh3_reference

    if skipped:
        logger.warning(
            "--no-novelty: prior art was not checked, so is_novel_enough is null rather "
            "than true for any design that clears the trastuzumab comparison"
        )
        return None
    if database is None:
        database = bundled_reference()
        if database is not None:
            logger.info("using the reference bundled with abguard ({})", database.name)
    if database is None:
        logger.error(
            "no reference database: this build ships none, so --reference-db is required "
            "to check novelty. Without it a design that clears the trastuzumab "
            "comparison is unchecked, not novel, and a published antibody would pass. "
            "Pass --no-novelty to validate structure and liabilities only."
        )
        raise typer.Exit(code=1)
    return cdrh3_reference(database, config=PipelineConfig())


def _configure_logging(verbose: bool) -> None:
    logger.remove()
    logger.add(
        sys.stderr,
        level="DEBUG" if verbose else "INFO",
        format="<level>{level: <8}</level> {message}",
    )


def _emit(frame: pl.DataFrame, output: Path | None, *, force_json: bool) -> None:
    """Write `frame` to `output`, or to stdout as JSON / a table."""
    if output is not None:
        if force_json and output.suffix.lower() not in {".json", ".ndjson", ".jsonl"}:
            output = output.with_suffix(".json")
            logger.info("liability output is JSON; writing {}", output)
        write_table(frame, output)
        return
    if force_json:
        typer.echo(frame.write_json())
    else:
        with pl.Config(tbl_rows=50, fmt_str_lengths=30, tbl_cols=-1):
            typer.echo(str(frame))


def _report_team(report: TeamReport) -> None:
    logger.info("{}: {}/{} design(s) valid", report.team, report.n_valid, report.n_input)
    for problem in report.problems():
        logger.warning("  {}", problem)


def _liability_frame(
    path: Path, config: PipelineConfig, reference: pl.LazyFrame | None = None
) -> pl.DataFrame:
    """Annotate one file without filtering anything."""
    annotated = annotate(read_table(path), config, reference=reference)
    n_broken = int(annotated["is_valid"].not_().sum())
    logger.info(
        "{}: {} design(s), {} with hard errors, {} liability occurrence(s)",
        path.name,
        annotated.height,
        n_broken,
        int(annotated["n_liabilities"].sum()),
    )
    return annotated


@app.command("team-validate")
def team_validate(
    filename: Annotated[
        Path,
        typer.Argument(
            exists=True,
            dir_okay=False,
            help=f"Submission table ({', '.join(SUPPORTED_SUFFIXES)}).",
        ),
    ],
    drop: DropOption = False,
    all_liabilities: AllLiabilitiesOption = False,
    output: OutputOption = None,
    reference_db: ReferenceDbOption = None,
    no_novelty: NoNoveltyOption = False,
    verbose: VerboseOption = False,
) -> None:
    """Validate one team's submission table.

    The table needs the columns sequence_id, kind, heavy_sequence, light_sequence and
    design_description. Rows are split on `kind` (vhh / scfv / paired) and each
    partition is validated against its own schema.
    """
    _configure_logging(verbose)
    config = PipelineConfig()
    reference = _reference(reference_db, skipped=no_novelty)

    if all_liabilities:
        _emit(_liability_frame(filename, config, reference), output, force_json=True)
        return

    try:
        library, report = validate_file(filename, config=config, drop=drop, reference=reference)
    except ValidationError as error:
        logger.error("{}", error)
        raise typer.Exit(code=1) from None

    _report_team(report)
    _emit(flatten(library), output, force_json=False)


@app.command("competition-validate")
def competition_validate(
    filename: Annotated[
        Path,
        typer.Argument(
            exists=True,
            help="A folder of submissions (one file per team) or a single file.",
        ),
    ],
    drop: DropOption = False,
    all_liabilities: AllLiabilitiesOption = False,
    output: OutputOption = None,
    pattern: Annotated[
        str, typer.Option("--pattern", help="Glob selecting submission files.")
    ] = "*",
    reference_db: ReferenceDbOption = None,
    no_novelty: NoNoveltyOption = False,
    verbose: VerboseOption = False,
) -> None:
    """Validate every team's submission in a folder and reject shared sequences.

    Each file is one team, named by its file stem, and is validated exactly as
    `team-validate` would. On top of that, no construct (heavy plus light sequence)
    may be submitted by two different teams; that is an error regardless of --drop.
    """
    _configure_logging(verbose)
    config = PipelineConfig()
    reference = _reference(reference_db, skipped=no_novelty)

    if filename.is_file():
        logger.warning("{} is a file; validating it as a single team", filename)
        paths = [filename]
    else:
        paths = None

    if all_liabilities:
        from .io import READERS

        targets = paths or sorted(
            path
            for path in filename.glob(pattern)
            if path.is_file() and path.suffix.lower() in READERS
        )
        if not targets:
            logger.error("{}: no submission files matching {!r}", filename, pattern)
            raise typer.Exit(code=1)
        frames = [
            _liability_frame(path, config, reference).with_columns(team=pl.lit(path.stem))
            for path in targets
        ]
        _emit(pl.concat(frames, how="diagonal_relaxed"), output, force_json=True)
        return

    try:
        if paths is not None:
            library, team_report = validate_file(
                paths[0], config=config, drop=drop, reference=reference
            )
            libraries = {team_report.team: library}
            report = CompetitionReport(root=filename.parent, teams=[team_report])
        else:
            libraries, report = validate_competition(
                filename, config=config, drop=drop, pattern=pattern, reference=reference
            )
    except ValidationError as error:
        logger.error("{}", error)
        raise typer.Exit(code=1) from None

    for team_report in report.teams:
        _report_team(team_report)
    logger.success(
        "{} team(s), {} design(s) valid, no cross-team duplicates",
        len(report.teams),
        sum(team.n_valid for team in report.teams),
    )

    combined = pl.concat(
        [flatten(library).with_columns(team=pl.lit(team)) for team, library in libraries.items()],
        how="diagonal_relaxed",
    )
    _emit(combined, output, force_json=False)


@app.command("liability-report")
def liability_report(
    filename: Annotated[
        Path, typer.Argument(exists=True, dir_okay=False, help="Submission table.")
    ],
    output: OutputOption = None,
    verbose: VerboseOption = False,
) -> None:
    """Summarise how often each LAP liability occurs in a submission."""
    _configure_logging(verbose)
    annotated = _liability_frame(filename, PipelineConfig())
    _emit(liability_summary(annotated), output, force_json=False)


@app.command("novelty-report")
def novelty_report(
    filename: Annotated[
        Path, typer.Argument(exists=True, dir_okay=False, help="Submission table.")
    ],
    reference_db: ReferenceDbOption = None,
    output: OutputOption = None,
    verbose: VerboseOption = False,
) -> None:
    """Show how novel each design is, without filtering anything.

    Reports the identity to trastuzumab, the novel / de_novo class it puts the design
    in, how many CDRH3 mutations that class requires, and the closest known CDRH3
    found. Without --reference-db the comparison is against trastuzumab alone.
    """
    _configure_logging(verbose)
    from .novelty import with_novelty

    graded = with_novelty(
        read_table(filename).lazy(), reference=_reference(reference_db), config=PipelineConfig()
    ).collect()
    n_failed = int(graded["is_novel_enough"].not_().sum())
    logger.info(
        "{}: {} of {} design(s) are novel enough",
        filename.name,
        graded.height - n_failed,
        graded.height,
    )
    _emit(
        graded.select(
            "sequence_id",
            "cdrh3",
            "cdrh3_confidence",
            "identity_to_trastuzumab",
            "novelty_class",
            "required_cdrh3_mutations",
            "cdrh3_min_distance",
            "cdrh3_nearest_source",
            "cdrh3_nearest_id",
            "is_novel_enough",
        ),
        output,
        force_json=False,
    )


@app.command("reference-ingest")
def reference_ingest(
    database: Annotated[
        Path, typer.Argument(dir_okay=False, help="DuckDB file to write into; created if absent.")
    ],
    filenames: Annotated[
        list[Path],
        typer.Argument(
            exists=True, dir_okay=False, help="Assay CSVs (or zipped CSVs) to add as tables."
        ),
    ],
    replace: Annotated[
        bool, typer.Option("--replace", help="Overwrite a table that already exists.")
    ] = False,
    verbose: VerboseOption = False,
) -> None:
    """Add assay CSVs to the reference database, one table per file.

    Each table is named after the file's stem and keeps every column the file had,
    plus `cdrh3_imgt`: the IMGT CDR3 immunum reads off the row's heavy chain. Run
    `reference-build` afterwards so the new rows reach the novelty gate.
    """
    _configure_logging(verbose)
    from .reference import ingest_csv

    rows = []
    for path in filenames:
        try:
            report = ingest_csv(database, path, replace=replace, config=PipelineConfig())
        except ValueError as error:
            logger.error("{}", error)
            raise typer.Exit(code=1) from None
        rows.append(report.model_dump())
    _emit(pl.DataFrame(rows), None, force_json=False)


@app.command("reference-build")
def reference_build(
    database: Annotated[
        Path, typer.Argument(exists=True, dir_okay=False, help="DuckDB reference database.")
    ],
    tables: Annotated[
        list[str] | None,
        typer.Option("--table", help="Index only this table. Repeatable."),
    ] = None,
    verbose: VerboseOption = False,
) -> None:
    """Derive the reference CDRH3s once, so grading runs do not have to.

    Every sequence in the database is IMGT numbered and the CDR3 of its heavy domain
    stored in a derived table. This is the slow step -- minutes, not seconds -- but it
    is per database, not per submission.
    """
    _configure_logging(verbose)
    from .reference import build_cdrh3_index

    try:
        report = build_cdrh3_index(database, tables=tables or None, config=PipelineConfig())
    except ValueError as error:
        logger.error("{}", error)
        raise typer.Exit(code=1) from None
    _emit(pl.DataFrame([table.model_dump() for table in report.tables]), None, force_json=False)
    logger.success("{:,} distinct reference CDRH3(s) in {:.1f}s", report.n_unique, report.seconds)


@app.command("reference-export")
def reference_export(
    database: Annotated[
        Path, typer.Argument(exists=True, dir_okay=False, help="DuckDB reference database.")
    ],
    destination: Annotated[
        Path, typer.Argument(file_okay=False, help="Bundle directory to write.")
    ],
    tables: Annotated[
        list[str] | None,
        typer.Option(
            "--table",
            help="Include only this table. Repeatable. The CDRH3 index is always included.",
        ),
    ] = None,
    compression: Annotated[str, typer.Option("--compression", help="Parquet codec.")] = "zstd",
    compression_level: Annotated[
        int | None,
        typer.Option(
            "--compression-level",
            help=f"Codec level. zstd defaults to {DEFAULT_COMPRESSION_LEVEL}, high on "
            "purpose: a bundle is written once and read many times.",
        ),
    ] = None,
    verbose: VerboseOption = False,
) -> None:
    """Package a reference database as a Parquet bundle, for shipping.

    One zstd Parquet file per table plus a manifest recording the numbering scheme and
    confidence floor the index was built with. polars scans a bundle directly, so this
    is what you hand to other people, and it needs no DuckDB to read.

    By default it ships the CDRH3 index alone -- 2.3 MB for the 610k loops derived from
    a 4.2 GB database, because that is all the gate reads. Pass the bundle to
    --reference-db like any database.
    """
    _configure_logging(verbose)
    from .reference import export_bundle

    try:
        manifest = export_bundle(
            database,
            destination,
            tables=tables or None,
            compression=compression,
            compression_level=compression_level,
            config=PipelineConfig(),
        )
    except ValueError as error:
        logger.error("{}", error)
        raise typer.Exit(code=1) from None
    _emit(pl.DataFrame([table.model_dump() for table in manifest.tables]), None, force_json=False)


@app.command("reference-info")
def reference_info(
    reference: Annotated[
        Path,
        typer.Argument(exists=True, help="Reference: a Parquet bundle or a DuckDB database."),
    ],
    verbose: VerboseOption = False,
) -> None:
    """List the tables in a reference and which column each is numbered on."""
    _configure_logging(verbose)
    from .reference import describe, is_bundle, read_manifest

    if is_bundle(reference):
        manifest = read_manifest(reference)
        logger.info(
            "bundle built by abguard {} with scheme={} min_confidence={} ({:.1f} MB {})",
            manifest.abguard_version,
            manifest.scheme,
            manifest.min_confidence,
            manifest.n_bytes / 1e6,
            manifest.compression,
        )
    _emit(describe(reference), None, force_json=False)


@app.command("reference")
def reference(verbose: VerboseOption = False) -> None:
    """Print the LAP Antibody Liability Reference this tool implements."""
    _configure_logging(verbose)
    frame = pl.DataFrame(
        [
            {
                "tag": rule.tag,
                "name": rule.name,
                "severity": rule.severity.value,
                "scope": rule.scope.value,
                "motif": rule.motif,
            }
            for rule in LAP_REFERENCE
        ]
    )
    with pl.Config(tbl_rows=-1, fmt_str_lengths=60, tbl_cols=-1):
        typer.echo(str(frame))


@app.command("dashboard")
def dashboard(
    filename: Annotated[
        Path | None,
        typer.Argument(
            help="Submission file or folder to open in the dashboard.",
        ),
    ] = None,
    edit: Annotated[
        bool, typer.Option("--edit", help="Open in marimo's editor instead of run mode.")
    ] = False,
) -> None:
    """Launch the marimo liability dashboard."""
    import os
    from importlib.resources import as_file, files

    # The notebook ships inside the package, so this works for a wheel, a `uvx .`
    # run and an editable install alike. `as_file` materialises it on disk when the
    # package is zipped, which marimo needs since it takes a path, not a module.
    with as_file(files("abguard.notebooks") / "dashboard.py") as notebook:
        if not notebook.exists():
            typer.echo(f"dashboard notebook not found at {notebook}", err=True)
            raise typer.Exit(code=1)
        env = dict(os.environ)
        if filename is not None:
            env["ABGUARD_INPUT"] = str(filename.resolve())
        # `python -m marimo` rather than bare `marimo`: the console script is not
        # guaranteed to be on PATH, but the interpreter running us always has the
        # dependency importable.
        argv = [
            sys.executable,
            "-m",
            "marimo",
            "edit" if edit else "run",
            str(notebook),
        ]
        logger.info("launching {}", " ".join(argv[2:]))
        os.execve(sys.executable, argv, env)


if __name__ == "__main__":
    app()
