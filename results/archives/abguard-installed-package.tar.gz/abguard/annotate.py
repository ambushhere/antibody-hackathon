"""Numbering, hard-check error kinds, and the full liability annotation.

Everything here is kind-agnostic: both sequence columns are numbered with
``chains=["ig"]`` and ``number_domains``, so a VHH column yields one domain, an scFv
column two, and a null column none, without the annotator needing to trust the
submitted ``kind``. The per-kind expectations in
:data:`~abguard.config.DOMAIN_SPEC` are then checked against what was actually found,
which is what makes ``wrong_domain_count`` catch a VHH mislabelled as an scFv.
"""

from __future__ import annotations

import immunum.polars as imp
import polars as pl
from loguru import logger

from .config import (
    AMINO_ACID_REGEX,
    ANY_IG,
    DOMAIN_SPEC,
    MAX_SEQUENCE_LENGTH,
    Chain,
    DesignKind,
    ErrorKind,
    PipelineConfig,
    sequence_column,
)
from .liabilities import LIABILITY_STRUCT_DTYPE, scan_column
from .novelty import NOVELTY_COLUMNS, NoveltyConfig, with_novelty

__all__ = [
    "ANNOTATION_COLUMNS",
    "annotate",
    "normalize",
    "with_errors",
    "with_liabilities",
    "with_novelty_errors",
    "with_numbering",
]

#: Columns the annotator adds on top of the input columns.
ANNOTATION_COLUMNS = (
    "heavy_domains",
    "light_domains",
    "n_domains",
    "chain_types",
    "min_confidence",
    "errors",
    "is_valid",
    "liabilities",
    "n_liabilities",
    "n_high_severity",
    "liability_tags",
    *NOVELTY_COLUMNS,
)


def normalize(frame: pl.DataFrame) -> pl.DataFrame:
    """Uppercase sequences and strip whitespace, gaps and empty strings.

    Submission tables come from spreadsheets and FASTA copy-paste, so leading
    whitespace, wrapped lines and lowercase residues are common and are not what the
    amino-acid check is meant to catch. Alignment gaps (``-`` and ``.``) are removed
    too. A sequence that is blank after stripping becomes null, so the nullability and
    domain-count checks fire rather than a confusing length check.
    """
    present = set(frame.columns)
    exprs: list[pl.Expr] = []
    for chain in Chain:
        column = sequence_column(chain)
        if column in present:
            exprs.append(
                pl.col(column)
                .cast(pl.String)
                .str.replace_all(r"[\s\-\.]", "")
                .str.to_uppercase()
                .replace("", None)
                .alias(column)
            )
    for column in ("sequence_id", "design_description"):
        if column in present:
            exprs.append(pl.col(column).cast(pl.String).str.strip_chars().alias(column))
    if "kind" in present:
        exprs.append(
            pl.col("kind")
            .cast(pl.String)
            .str.strip_chars()
            .str.to_lowercase()
            .replace("", None)
            .alias("kind")
        )
    return frame.with_columns(exprs) if exprs else frame


def _numbered_columns(frame: pl.DataFrame) -> list[Chain]:
    return [chain for chain in Chain if sequence_column(chain) in frame.columns]


def with_numbering(frame: pl.DataFrame, config: PipelineConfig) -> pl.DataFrame:
    """Add raw per-domain numbering and segmentation lists for each sequence column.

    The lists are wide (one entry per residue of every domain); :func:`annotate` drops
    them again once the liabilities have been scanned.
    """
    exprs: list[pl.Expr] = []
    for chain in _numbered_columns(frame):
        column = sequence_column(chain)
        kwargs = {
            "chains": ANY_IG,
            "scheme": config.scheme,
            "min_confidence": config.min_confidence,
        }
        exprs.append(imp.number_domains(column, **kwargs).alias(f"_{column}_domains"))
        exprs.append(imp.segment_domains(column, **kwargs).alias(f"_{column}_segments"))
    return frame.with_columns(exprs)


def _domain_field(column: str, field: str) -> pl.Expr:
    """The `field` of every domain found in `column`, as a list."""
    return pl.col(f"_{column}_domains").list.eval(pl.element().struct.field(field)).fill_null([])


def _numbered_domain_count(column: str) -> pl.Expr:
    """How many domains in `column` numbered cleanly (error_kind null)."""
    return (
        pl.col(f"_{column}_domains")
        .list.eval(pl.element().struct.field("error_kind").is_null().cast(pl.Int32))
        .list.sum()
        .fill_null(0)
    )


def _expected_domains(chain: Chain) -> pl.Expr:
    """The domain count the row's ``kind`` requires in `chain`'s column, or 0."""
    expected = pl.lit(0, dtype=pl.Int32)
    for kind, spec in DOMAIN_SPEC.items():
        if chain in spec:
            expected = (
                pl.when(pl.col("kind") == kind.value)
                .then(pl.lit(spec[chain].n_domains, dtype=pl.Int32))
                .otherwise(expected)
            )
    return expected


def _error_conditions(
    frame: pl.DataFrame, config: PipelineConfig
) -> list[tuple[ErrorKind, pl.Expr]]:
    """Every hard check, as (error kind, "row is broken" expression) pairs."""
    known = [kind.value for kind in DesignKind]
    conditions: list[tuple[ErrorKind, pl.Expr]] = [
        (
            ErrorKind.DUPLICATE_SEQUENCE_ID,
            pl.col("sequence_id").is_duplicated() | pl.col("sequence_id").is_null(),
        ),
        (ErrorKind.UNKNOWN_KIND, ~pl.col("kind").is_in(known) | pl.col("kind").is_null()),
    ]
    # Per-column checks only make sense once the kind is known: which columns are
    # required, and how many domains they need, both come from it.
    kind_known = pl.col("kind").is_in(known)
    for chain in _numbered_columns(frame):
        column = sequence_column(chain)
        sequence = pl.col(column)
        present = sequence.is_not_null()
        expected = _expected_domains(chain)
        required = expected > 0
        numbered_cleanly = (
            _domain_field(column, "error_kind").list.eval(pl.element().is_null()).list.all()
        )
        conditions += [
            (ErrorKind.MISSING_SEQUENCE, kind_known & required & sequence.is_null()),
            (ErrorKind.UNEXPECTED_SEQUENCE, kind_known & ~required & present),
            (
                ErrorKind.INVALID_AMINO_ACIDS,
                present & ~sequence.str.contains(AMINO_ACID_REGEX),
            ),
            (
                ErrorKind.SEQUENCE_TOO_LONG,
                present & (sequence.str.len_chars() > MAX_SEQUENCE_LENGTH),
            ),
            (
                ErrorKind.UNPAIRED_CYSTEINE,
                present
                & (
                    (sequence.str.count_matches("C") % 2 == 1)
                    | ~_domain_field(column, "numbering")
                    .list.eval(
                        pl.element()
                        .list.eval((pl.element().struct.field("residue") == "C").cast(pl.Int32))
                        .list.sum()
                        % 2
                        == 0
                    )
                    .list.all()
                ),
            ),
            (ErrorKind.NUMBERING_FAILED, present & ~numbered_cleanly),
            # Only meaningful once every domain numbered: a sequence immunum could not
            # number at all is already reported as `numbering_failed`, and saying its
            # domain count is wrong too adds nothing.
            (
                ErrorKind.WRONG_DOMAIN_COUNT,
                kind_known
                & required
                & numbered_cleanly
                & (_numbered_domain_count(column) != expected),
            ),
        ]
    return conditions


def with_errors(frame: pl.DataFrame, config: PipelineConfig) -> pl.DataFrame:
    """Add the ``errors`` list column and the ``is_valid`` flag.

    ``errors`` holds one :class:`~abguard.config.ErrorKind` per failed hard check,
    deduplicated across columns, and is empty for a compliant row. Requires
    :func:`with_numbering` to have run.
    """
    flags = [
        pl.when(condition.fill_null(False))
        .then(pl.lit(kind.value))
        .otherwise(None)
        .alias(f"__flag{index}")
        for index, (kind, condition) in enumerate(_error_conditions(frame, config))
    ]
    return frame.with_columns(
        pl.concat_list(flags).list.drop_nulls().list.unique(maintain_order=True).alias("errors")
    ).with_columns(is_valid=pl.col("errors").list.len() == 0)


def with_liabilities(frame: pl.DataFrame, config: PipelineConfig) -> pl.DataFrame:
    """Add the ``liabilities`` struct list plus its summary columns.

    Scanning runs in Python (regex over the IMGT regions of each domain), which is
    fine at submission-table scale -- thousands of rows, not millions. Requires
    :func:`with_numbering` to have run.
    """
    columns = [
        sequence_column(chain)
        for chain in Chain
        if f"_{sequence_column(chain)}_segments" in frame.columns
    ]
    inputs = pl.struct(
        [name for column in columns for name in (f"_{column}_segments", f"_{column}_domains")]
    )

    def scan(row: dict) -> list[dict]:
        hits = [
            hit
            for column in columns
            for hit in scan_column(
                column, row[f"_{column}_segments"], row[f"_{column}_domains"], config
            )
        ]
        return [hit.model_dump(mode="json") for hit in hits]

    return frame.with_columns(
        inputs.map_elements(scan, return_dtype=pl.List(LIABILITY_STRUCT_DTYPE)).alias("liabilities")
    ).with_columns(
        n_liabilities=pl.col("liabilities").list.len(),
        liability_tags=pl.col("liabilities")
        .list.eval(pl.element().struct.field("tag"))
        .list.unique(maintain_order=True),
        n_high_severity=pl.col("liabilities")
        .list.eval((pl.element().struct.field("severity") == "high").cast(pl.Int32))
        .list.sum(),
    )


def _domain_summary(frame: pl.DataFrame) -> list[pl.Expr]:
    """Compact, human-readable columns describing what immunum found."""
    columns = [
        sequence_column(chain)
        for chain in Chain
        if f"_{sequence_column(chain)}_domains" in frame.columns
    ]
    exprs = [
        _numbered_domain_count(column).alias(f"{column.removesuffix('_sequence')}_domains")
        for column in columns
    ]
    if columns:
        exprs += [
            pl.sum_horizontal([_numbered_domain_count(column) for column in columns]).alias(
                "n_domains"
            ),
            pl.concat_list([_domain_field(column, "chain") for column in columns])
            .list.drop_nulls()
            .alias("chain_types"),
            pl.concat_list([_domain_field(column, "confidence") for column in columns])
            .list.drop_nulls()
            .list.min()
            .alias("min_confidence"),
        ]
    return exprs


def with_novelty_errors(
    frame: pl.DataFrame,
    *,
    reference: pl.LazyFrame | None = None,
    config: PipelineConfig | None = None,
    novelty: NoveltyConfig | None = None,
    gate: bool | None = None,
) -> pl.DataFrame:
    """Add the novelty columns and, when gating, fold the verdict into ``errors``.

    Kept apart from :func:`with_errors` because the novelty gate is the one hard
    check that cannot be decided from the row on its own: it needs the reference
    CDRH3s, which arrive at runtime. Everything else in ``errors`` is a pure
    expression over the submission table.

    `gate` defaults to "whenever a `reference` was supplied". Grading against
    trastuzumab alone still fills in the novelty columns, but it is not the
    competition rule -- that rule is "distant from trastuzumab *and* from everything
    known" -- so a missing database reports rather than rejects, and a submission is
    never failed by a check that was only half applied.

    Requires ``errors`` and ``is_valid`` to be present already.
    """
    gate = reference is not None if gate is None else gate
    graded = with_novelty(frame.lazy(), reference=reference, config=config, novelty=novelty)
    if not gate:
        return graded.collect()
    return (
        graded.with_columns(
            # `fill_null(False)`: a gate fails closed. A null verdict means the
            # novelty check did not run, and an unchecked design must not pass a gate.
            errors=pl.when(pl.col("is_novel_enough").fill_null(False))
            .then(pl.col("errors"))
            .otherwise(
                pl.col("errors").list.set_union([ErrorKind.INSUFFICIENT_CDRH3_NOVELTY.value])
            )
        )
        .with_columns(is_valid=pl.col("errors").list.len() == 0)
        .collect()
    )


def annotate(
    frame: pl.DataFrame,
    config: PipelineConfig | None = None,
    *,
    include_liabilities: bool = True,
    reference: pl.LazyFrame | None = None,
    novelty: NoveltyConfig | None = None,
    gate_novelty: bool | None = None,
) -> pl.DataFrame:
    """Run the whole annotation pipeline on a submission table.

    Nothing is filtered: every input row comes back, carrying its hard-validation
    ``errors`` and, unless `include_liabilities` is false, every LAP liability found
    in it. This is what ``--all-liabilities`` reports and what the dashboard reads.

    Args:
        frame: the raw submission table.
        config: numbering and hard-check configuration.
        include_liabilities: scan for LAP liabilities.
        reference: reference CDRH3s from
            :func:`~abguard.reference.cdrh3_reference`. When given, the novelty gate
            runs and contributes ``insufficient_cdrh3_novelty`` to ``errors``; the
            :data:`~abguard.novelty.NOVELTY_COLUMNS` are added either way, graded
            against trastuzumab alone when it is None.
        novelty: novelty thresholds.
        gate_novelty: whether a failed novelty check counts as a hard error. Defaults
            to whether `reference` was given.
    """
    config = config or PipelineConfig()
    logger.debug("annotating {} rows (scheme={})", frame.height, config.scheme)

    annotated = with_errors(with_numbering(normalize(frame), config), config)
    if include_liabilities:
        annotated = with_liabilities(annotated, config)
    annotated = annotated.with_columns(_domain_summary(annotated))
    annotated = with_novelty_errors(
        annotated, reference=reference, config=config, novelty=novelty, gate=gate_novelty
    )

    return annotated.select(pl.exclude("^_.*$", "^__flag.*$"))
