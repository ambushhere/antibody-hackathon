"""The Antibody Liability Reference and a scanner for it.

The motif table is Table 1 of the LAP paper:

    Satława T. et al. (2024) "LAP: Liability Antibody Profiler by sequence &
    structural mapping of natural and therapeutic antibodies."
    PLOS Comput Biol 20(3): e1011881. https://doi.org/10.1371/journal.pcbi.1011881

Liabilities are matched inside IMGT-defined regions of IMGT-numbered sequences, so
every scan needs an immunum segmentation (for the region boundaries) and numbering
(for the position-scoped cysteine rules). Following the paper's conclusion that
"IMGT CDRs plus one flanking residue captures nearly all" germline liabilities,
CDR-scoped motifs are matched over each CDR widened by
:attr:`~abguard.config.PipelineConfig.cdr_flank` residues.

Note that these motifs are deliberately over-predictive: the paper finds that
upwards of 90% of real antibody sequences carry at least one. They are reported,
never used to reject a row.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from enum import StrEnum

import polars as pl
from pydantic import BaseModel, Field

from .config import CANONICAL_CYSTEINE_POSITIONS, PipelineConfig

__all__ = [
    "LAP_REFERENCE",
    "LIABILITY_STRUCT_DTYPE",
    "LiabilityHit",
    "LiabilityRule",
    "Scope",
    "Severity",
    "scan_column",
    "scan_domain",
]


class Severity(StrEnum):
    """LAP severity tier of a liability."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Scope(StrEnum):
    """Where in the variable domain a rule is matched."""

    #: Inside CDR1/2/3, widened by ``cdr_flank`` residues of framework.
    CDR = "cdr"
    #: Anywhere in the numbered variable fragment (FR1 through FR4).
    FV = "fv"
    #: Not a motif: evaluated against IMGT position numbers (the cysteine rules).
    POSITION = "position"


class LiabilityRule(BaseModel):
    """One row of the LAP Antibody Liability Reference."""

    model_config = {"frozen": True}

    tag: str = Field(description="LAP short name, e.g. 'DeAmdH'")
    name: str = Field(description="human-readable liability name")
    severity: Severity
    scope: Scope
    motif: str = Field(description="motif as written in the paper, for display")
    pattern: str | None = Field(
        default=None, description="regex implementing `motif`; None for POSITION scope"
    )
    description: str

    def compiled(self) -> re.Pattern[str]:
        if self.pattern is None:
            raise ValueError(f"rule {self.tag} is position-scoped and has no regex")
        return re.compile(self.pattern)


class LiabilityHit(BaseModel):
    """A single detected liability occurrence."""

    model_config = {"frozen": True}

    tag: str
    name: str
    severity: Severity
    column: str = Field(description="input column the hit is in, e.g. 'heavy_sequence'")
    domain_index: int = Field(description="0-based index of the variable domain within that column")
    chain: str | None = Field(
        default=None, description="chain type immunum detected for the domain, e.g. 'H'"
    )
    region: str = Field(description="IMGT region the hit starts in, e.g. 'cdr3'")
    motif: str = Field(description="the residues actually matched")
    start: int = Field(description="0-based offset of the match within the domain's numbered Fv")
    imgt_positions: list[str] = Field(
        default_factory=list, description="IMGT position labels covered by the match"
    )


#: Polars dtype of the ``liabilities`` column produced by the annotator.
LIABILITY_STRUCT_DTYPE = pl.Struct(
    {
        "tag": pl.String,
        "name": pl.String,
        "severity": pl.String,
        "column": pl.String,
        "domain_index": pl.Int32,
        "chain": pl.String,
        "region": pl.String,
        "motif": pl.String,
        "start": pl.Int32,
        "imgt_positions": pl.List(pl.String),
    }
)


LAP_REFERENCE: tuple[LiabilityRule, ...] = (
    LiabilityRule(
        tag="DeAmdH",
        name="Deamidation (high)",
        severity=Severity.HIGH,
        scope=Scope.CDR,
        motif="N[GS] in CDRs",
        pattern="N[GS]",
        description=(
            "Deamidation of asparagine in an NG or NS motif. Associated with degradation "
            "and reduced shelf-life."
        ),
    ),
    LiabilityRule(
        tag="FragH",
        name="Fragmentation (high)",
        severity=Severity.HIGH,
        scope=Scope.CDR,
        motif="DP in CDRs",
        pattern="DP",
        description=(
            "Cleavage at the aspartate-proline interface; a common motif susceptible to "
            "pH-driven hydrolysis."
        ),
    ),
    LiabilityRule(
        tag="Isom",
        name="Isomerization",
        severity=Severity.HIGH,
        scope=Scope.CDR,
        motif="D[DGHST] in CDRs",
        pattern="D[DGHST]",
        description=(
            "Isomerization of aspartate in DD, DG, DH, DS or DT motifs; shortens shelf-life."
        ),
    ),
    LiabilityRule(
        tag="mCys",
        name="Missing cysteine",
        severity=Severity.HIGH,
        scope=Scope.POSITION,
        motif=f"C not present at IMGT {' or '.join(CANONICAL_CYSTEINE_POSITIONS)}",
        description=(
            "One of the two canonical intra-domain cysteines is absent, which can change "
            "the fold, surface charge or hydrophobicity."
        ),
    ),
    LiabilityRule(
        tag="xCys",
        name="Extra cysteine",
        severity=Severity.HIGH,
        scope=Scope.POSITION,
        motif=f"C present outside IMGT {' and '.join(CANONICAL_CYSTEINE_POSITIONS)}",
        description=(
            "A cysteine at a non-canonical IMGT position; unpaired cysteines can alter "
            "structure, apparent surface charge or hydrophobicity."
        ),
    ),
    LiabilityRule(
        tag="Ngly",
        name="N-linked glycosylation",
        severity=Severity.HIGH,
        scope=Scope.FV,
        motif="N[^P][ST] in variable fragment",
        pattern="N[^P][ST]",
        description=(
            "N-linked glycosylation sequon. Reduces conformational stability and "
            "shelf-life; in a CDR it can directly impair antigen recognition."
        ),
    ),
    LiabilityRule(
        tag="DeAmdM",
        name="Deamidation (medium)",
        severity=Severity.MEDIUM,
        scope=Scope.CDR,
        motif="N[AHNT] in CDRs",
        pattern="N[AHNT]",
        description="Deamidation in NA, NH, NN or NT motifs; less common than NG/NS.",
    ),
    LiabilityRule(
        tag="Hydro",
        name="Hydrolysis",
        severity=Severity.MEDIUM,
        scope=Scope.CDR,
        motif="NP in CDRs",
        pattern="NP",
        description=(
            "Hydrolysis; gives rise to the DP fragmentation motif once the asparagine "
            "deamidates to aspartate."
        ),
    ),
    LiabilityRule(
        tag="FragM",
        name="Fragmentation (medium)",
        severity=Severity.MEDIUM,
        scope=Scope.CDR,
        motif="TS in CDRs",
        pattern="TS",
        description="pH-dependent cleavage at the threonine-serine interface.",
    ),
    LiabilityRule(
        tag="TrpOx",
        name="Trp oxidation",
        severity=Severity.MEDIUM,
        scope=Scope.CDR,
        motif="W in CDRs",
        pattern="W",
        description="Tryptophan oxidation, a post-translational modification.",
    ),
    LiabilityRule(
        tag="MetOx",
        name="Met oxidation",
        severity=Severity.MEDIUM,
        scope=Scope.CDR,
        motif="M in CDRs",
        pattern="M",
        description=(
            "Methionine oxidation in a CDR; linked to reduced binding affinity and "
            "faster degradation."
        ),
    ),
    LiabilityRule(
        tag="DeAmdL",
        name="Deamidation (low)",
        severity=Severity.LOW,
        scope=Scope.CDR,
        motif="[STK]N in CDRs",
        pattern="[STK]N",
        description="Deamidation in SN, TN or KN motifs; least common tier.",
    ),
    LiabilityRule(
        tag="IntBind",
        name="Integrin binding",
        severity=Severity.LOW,
        scope=Scope.FV,
        motif="GPR|RGD|RYD|LDV|DGE|KGD|NGR in variable fragment",
        pattern="GPR|RGD|RYD|LDV|DGE|KGD|NGR",
        description=(
            "Integrin-binding motif: aVb3 (RGD/RYD/KGD/NGR), a4b1 (LDV), a2b1 (DGE), "
            "CD11c/CD18 (GPR)."
        ),
    ),
)

#: Rules keyed by LAP tag.
RULES_BY_TAG: dict[str, LiabilityRule] = {rule.tag: rule for rule in LAP_REFERENCE}

#: The IMGT regions a segmentation yields, in sequence order, excluding prefix/postfix.
FV_REGIONS = ("fr1", "cdr1", "fr2", "cdr2", "fr3", "cdr3", "fr4")

#: Which of those are CDRs.
CDR_REGIONS = ("cdr1", "cdr2", "cdr3")


class _FvLayout:
    """The numbered variable fragment, with region spans and IMGT position labels."""

    def __init__(
        self,
        segments: dict[str, str | None],
        numbering: list[dict[str, str]] | None,
    ) -> None:
        self.sequence = ""
        self.spans: dict[str, tuple[int, int]] = {}
        for region in FV_REGIONS:
            part = segments.get(region) or ""
            start = len(self.sequence)
            self.sequence += part
            self.spans[region] = (start, start + len(part))

        # immunum numbers exactly the residues that make up fr1..fr4, in order, so the
        # i-th numbered residue is self.sequence[i]. Only trust that when the lengths
        # agree -- otherwise fall back to unlabelled positions.
        labels: list[str | None] = [None] * len(self.sequence)
        if numbering is not None and len(numbering) == len(self.sequence):
            labels = [entry.get("position") for entry in numbering]
        self.labels = labels

    def region_at(self, offset: int) -> str:
        for region, (start, end) in self.spans.items():
            if start <= offset < end:
                return region
        return "unknown"

    def positions(self, start: int, end: int) -> list[str]:
        return [label for label in self.labels[start:end] if label is not None]

    def search_window(self, region: str, flank: int) -> tuple[int, int]:
        start, end = self.spans[region]
        return max(0, start - flank), min(len(self.sequence), end + flank)


def _iter_matches(
    rule: LiabilityRule, layout: _FvLayout, window: tuple[int, int]
) -> Iterator[re.Match[str]]:
    """Yield matches of `rule` that *start* inside `window`.

    A motif may extend past the window (the paper notes two-residue motifs straddling
    a CDR/framework boundary), so the regex runs over the whole Fv and matches are
    filtered by start offset.
    """
    lo, hi = window
    for match in rule.compiled().finditer(layout.sequence):
        if lo <= match.start() < hi:
            yield match


class _Site:
    """Where a scan is running: one numbered variable domain of one column."""

    def __init__(self, column: str, domain_index: int, chain: str | None) -> None:
        self.column = column
        self.domain_index = domain_index
        self.chain = chain

    def hit(
        self,
        rule: LiabilityRule,
        *,
        region: str,
        motif: str,
        start: int,
        imgt_positions: list[str],
    ) -> LiabilityHit:
        """Build a hit for `rule` at this site."""
        return LiabilityHit(
            tag=rule.tag,
            name=rule.name,
            severity=rule.severity,
            column=self.column,
            domain_index=self.domain_index,
            chain=self.chain,
            region=region,
            motif=motif,
            start=start,
            imgt_positions=imgt_positions,
        )


def _scan_cysteines(layout: _FvLayout, site: _Site) -> Iterator[LiabilityHit]:
    """Apply the two IMGT-position-scoped cysteine rules."""
    labelled = [(offset, label) for offset, label in enumerate(layout.labels) if label is not None]
    if not labelled:
        return

    by_position = {label: offset for offset, label in labelled}

    for canonical in CANONICAL_CYSTEINE_POSITIONS:
        offset = by_position.get(canonical)
        if offset is None or layout.sequence[offset] != "C":
            yield site.hit(
                RULES_BY_TAG["mCys"],
                region=layout.region_at(offset) if offset is not None else "unknown",
                motif=f"no C at IMGT {canonical}",
                start=offset if offset is not None else -1,
                imgt_positions=[canonical],
            )

    for offset, label in labelled:
        if layout.sequence[offset] == "C" and label not in CANONICAL_CYSTEINE_POSITIONS:
            yield site.hit(
                RULES_BY_TAG["xCys"],
                region=layout.region_at(offset),
                motif=f"C at IMGT {label}",
                start=offset,
                imgt_positions=[label],
            )


def scan_domain(
    segments: dict[str, str | None] | None,
    numbering: list[dict[str, str]] | None,
    *,
    column: str,
    domain_index: int = 0,
    chain: str | None = None,
    config: PipelineConfig | None = None,
) -> list[LiabilityHit]:
    """Find every LAP liability in one numbered variable domain.

    Args:
        segments: one element of an ``immunum.polars.segment_domains`` list, as a
            dict. ``None``, or a segmentation whose ``error_kind`` is set, yields no
            hits -- a domain immunum could not number has no IMGT regions to search.
        numbering: the matching domain's ``numbering`` list from
            ``immunum.polars.number_domains``. Used for the IMGT-position cysteine
            rules and to label motif hits; optional, and the cysteine rules are
            skipped without it.
        column: input column this domain came from, for labelling hits.
        domain_index: 0-based index of this domain within that column.
        chain: chain type immunum detected for this domain.
        config: pipeline configuration; defaults are the competition settings.

    Returns:
        Hits ordered by position within the domain's variable fragment.
    """
    if segments is None or segments.get("error_kind") is not None:
        return []

    config = config or PipelineConfig()
    layout = _FvLayout(segments, numbering)
    if not layout.sequence:
        return []

    site = _Site(column, domain_index, chain)
    hits: list[LiabilityHit] = []
    for rule in LAP_REFERENCE:
        if rule.scope is Scope.POSITION:
            continue
        if rule.scope is Scope.CDR:
            windows = [layout.search_window(region, config.cdr_flank) for region in CDR_REGIONS]
        else:
            windows = [(0, len(layout.sequence))]
        for window in windows:
            for match in _iter_matches(rule, layout, window):
                hits.append(
                    site.hit(
                        rule,
                        region=layout.region_at(match.start()),
                        motif=match.group(0),
                        start=match.start(),
                        imgt_positions=layout.positions(match.start(), match.end()),
                    )
                )

    hits.extend(_scan_cysteines(layout, site))
    hits.sort(key=lambda hit: (hit.start, hit.tag))
    return hits


def scan_column(
    column: str,
    domain_segments: list[dict[str, str | None]] | None,
    domain_numbering: list[dict] | None,
    config: PipelineConfig | None = None,
) -> list[LiabilityHit]:
    """Scan every variable domain immunum found in one sequence column.

    This is the kind-agnostic entry point: a VHH column has one domain, an scFv
    column two, and a null sequence none. Hits are labelled with the column, the
    domain's index within it, and the chain type immunum detected.

    Args:
        column: the input column name, e.g. ``"heavy_sequence"``.
        domain_segments: the ``immunum.polars.segment_domains`` list for the column.
        domain_numbering: the ``immunum.polars.number_domains`` list for the column,
            used to recover each domain's chain type and IMGT positions.
        config: pipeline configuration.

    Returns:
        Hits from every domain, ordered by domain then position.
    """
    if not domain_segments:
        return []
    numbering = domain_numbering or []
    hits: list[LiabilityHit] = []
    for index, segments in enumerate(domain_segments):
        domain = numbering[index] if index < len(numbering) else {}
        hits += scan_domain(
            segments,
            (domain or {}).get("numbering"),
            column=column,
            domain_index=index,
            chain=(domain or {}).get("chain"),
            config=config,
        )
    return hits
