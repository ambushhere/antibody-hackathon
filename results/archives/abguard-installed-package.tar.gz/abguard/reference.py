"""The CDRH3 reference database: the prior art the novelty gate measures against.

:mod:`abguard.novelty` needs one thing from the outside world -- every CDRH3 that is
already known -- and this module produces it from a DuckDB file, as a two-column
``(cdrh3, source)`` frame.

What is in the database
-----------------------
The binder-prescreen DuckDB holds one table per prior-art arm (``pdb``,
``swissprot``, ``plabdab``, ``therasabdab``, ``uspto``, ...), each
``(id, description, seq, length)``, plus an ``arms`` table describing them. Those
``seq`` values are **whole protein sequences**, not CDRH3s. Assay tables added with
:func:`ingest_csv` instead carry a ``vh_sequence`` per assayed variant.

Neither form can be compared with a design's CDRH3 directly, which is the trap this
module exists to avoid. The HER2 assay tables ship a ``cdrh3`` column holding the
10-mer *core* that the library randomised (``WGGDGFYAMD``), while the IMGT CDR3 of
the same antibody is the 13-mer ``SRWGGDGFYAMDY``. Taking those cores at face value
would credit every design with three free mutations from the ``SR``/``Y`` flanks and
let an exact copy of a known binder through the gate. So every reference sequence is
re-numbered here and its IMGT CDR3 derived by the same immunum call that reads a
submission -- the original ``cdrh3`` column is preserved but never graded against.

Building the index
------------------
Re-numbering is far too slow to redo per run over millions of sequences, so
:func:`build_cdrh3_index` does it once and materialises the result as the
:data:`INDEX_TABLE` table inside the same DuckDB file. :func:`cdrh3_reference` then
just scans that table. Sequences that do not number as an IGH domain -- light
chains, and the great majority of ``swissprot`` and ``uspto``, which are not
antibodies at all -- carry no CDRH3 and are dropped.

Moving data across
------------------
Everything passes between DuckDB and polars as Parquet: DuckDB's own ``COPY ... TO``
and ``read_parquet`` on one side, :func:`polars.scan_parquet` on the other. DuckDB's
dataframe interop (``to_arrow_table``, ``register``) needs pyarrow, a 40 MB
dependency this package would otherwise not have, and Parquet is both lighter and
lazier -- polars reads a slice of it without materialising the rest, which is what
keeps indexing a multi-million-row arm inside bounded memory.
"""

from __future__ import annotations

import re
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory

import duckdb
import immunum.polars as imp
import polars as pl
from loguru import logger
from pydantic import BaseModel, Field

from .config import ANY_IG, PipelineConfig

__all__ = [
    "BUNDLED_REFERENCE",
    "BUNDLE_FORMAT",
    "BUNDLE_MANIFEST",
    "DEFAULT_COMPRESSION_LEVEL",
    "ID_COLUMNS",
    "INDEX_TABLE",
    "SEQUENCE_COLUMNS",
    "BundleManifest",
    "BundleTable",
    "IndexReport",
    "TableIndex",
    "build_cdrh3_index",
    "bundle_table",
    "cdrh3_reference",
    "describe",
    "export_bundle",
    "heavy_cdr3",
    "ingest_csv",
    "is_bundle",
    "read_manifest",
    "reference_cache",
    "table_name",
]

#: The derived table :func:`build_cdrh3_index` writes and :func:`cdrh3_reference`
#: reads. Prefixed so it is obviously not one of the upstream arm tables.
INDEX_TABLE = "abguard_cdrh3"

#: Columns that may hold the sequence to number, in order of preference. An assay
#: table names its heavy chain ``vh_sequence``; a prior-art arm names it ``seq``.
SEQUENCE_COLUMNS = ("vh_sequence", "heavy_sequence", "seq", "sequence")

#: Columns that may identify the entry a sequence came from, in order of preference.
#: Carried into the index so a collision can name the record it hit, not just the
#: table: "in pdb" is a start, "7eow_B in pdb" is actionable. Assay tables have no
#: such column and contribute a null.
ID_COLUMNS = ("id", "accession", "name")

#: A DuckDB identifier this module is willing to interpolate into SQL.
_SAFE_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class TableIndex(BaseModel):
    """What indexing one table yielded."""

    table: str
    column: str = Field(description="the column that was numbered")
    n_rows: int
    n_cdrh3: int = Field(description="rows that numbered as an IGH domain")
    seconds: float = Field(
        default=0.0,
        description="wall clock, when this table was processed on its own; 0 for the "
        "index build, which numbers every table in one query",
    )

    @property
    def n_skipped(self) -> int:
        return self.n_rows - self.n_cdrh3


class IndexReport(BaseModel):
    """Outcome of building the CDRH3 index."""

    database: Path
    tables: list[TableIndex] = Field(default_factory=list)
    n_unique: int = 0
    seconds: float = 0.0

    @property
    def n_cdrh3(self) -> int:
        return sum(table.n_cdrh3 for table in self.tables)


def _quote(name: str) -> str:
    """Validate a table or column name and quote it for SQL."""
    if not _SAFE_NAME.match(name):
        raise ValueError(f"{name!r} is not a plain SQL identifier; refusing to interpolate it")
    return f'"{name}"'


def _literal(path: Path) -> str:
    """A path as a SQL string literal."""
    return "'" + str(path).replace("'", "''") + "'"


def _literal_str(value: str) -> str:
    """A plain string as a SQL literal."""
    return "'" + value.replace("'", "''") + "'"


def _export(con: duckdb.DuckDBPyConnection, query: str, destination: Path) -> Path:
    """Run `query` and write its rows to `destination` as Parquet."""
    con.execute(f"COPY ({query}) TO {_literal(destination)} (FORMAT PARQUET)")
    return destination


def _load(con: duckdb.DuckDBPyConnection, frame: pl.DataFrame, table: str, scratch: Path) -> None:
    """Replace `table` in `con` with the contents of `frame`, via Parquet."""
    staged = scratch / f"{table}.load.parquet"
    frame.write_parquet(staged)
    con.execute(
        f"CREATE OR REPLACE TABLE {_quote(table)} AS SELECT * FROM read_parquet({_literal(staged)})"
    )
    staged.unlink(missing_ok=True)


def table_name(path: Path) -> str:
    """The table a file is ingested under: its stem, with every suffix removed.

    ``tz_her2_facs_3classes_524346.csv.zip`` becomes
    ``tz_her2_facs_3classes_524346``; :meth:`Path.stem` alone would leave the
    ``.csv``.
    """
    name = path.name
    for suffix in reversed(path.suffixes):
        name = name.removesuffix(suffix)
    if not _SAFE_NAME.match(name):
        raise ValueError(f"{path.name}: stem {name!r} is not usable as a table name")
    return name


def heavy_cdr3(column: str, config: PipelineConfig | None = None) -> pl.Expr:
    """The IMGT CDR3 of the first cleanly-numbered IGH domain in `column`.

    Null when `column` holds no heavy variable domain -- a light chain, a
    non-antibody protein, or an unparseable string.

    Numbering offers immunum all of IGH/IGK/IGL and then keeps the domains it labelled
    ``H``, rather than asking for heavy chains only. Restricting the chain set looks
    cheaper -- one pass, and everything returned is heavy by construction -- but it
    leaves the confidence floor as the only thing standing between a light chain and a
    heavy-chain alignment, and at :data:`~abguard.config.MIN_CONFIDENCE` immunum will
    force-fit trastuzumab's VL as ``H`` at 0.11. That would fill the index with light
    chain CDR3s labelled as CDRH3. See :data:`~abguard.config.ANY_IG`.
    """
    config = config or PipelineConfig()
    kwargs = _numbering_kwargs(config)
    heavy = _heavy_mask(imp.number_domains(column, **kwargs))
    segments = imp.segment_domains(column, **kwargs)
    return (
        pl.when(heavy.list.any())
        .then(segments.list.get(heavy.list.arg_max(), null_on_oob=True).struct.field("cdr3"))
        .otherwise(None)
    )


def _numbering_kwargs(config: PipelineConfig) -> dict[str, object]:
    return {
        "chains": ANY_IG,
        "scheme": config.scheme,
        "min_confidence": config.min_confidence,
    }


def _heavy_mask(numbered: pl.Expr) -> pl.Expr:
    """Per-domain flags: is this a cleanly-numbered IGH domain?"""
    return numbered.list.eval(
        pl.element().struct.field("chain").is_in(["H"])
        & pl.element().struct.field("error_kind").is_null()
    )


def _describe_duckdb(database: Path) -> pl.DataFrame:
    """:func:`describe` for a DuckDB file."""
    with duckdb.connect(str(database), read_only=True) as con:
        rows = []
        for (name,) in con.execute(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema = 'main' ORDER BY table_name"
        ).fetchall():
            columns = {
                column
                for (column,) in con.execute(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_schema = 'main' AND table_name = ?",
                    [name],
                ).fetchall()
            }
            column = next(
                (candidate for candidate in SEQUENCE_COLUMNS if candidate in columns), None
            )
            identifier = next((candidate for candidate in ID_COLUMNS if candidate in columns), None)
            count = con.execute(f"SELECT count(*) FROM {_quote(name)}").fetchone()
            rows.append(
                {
                    "table": name,
                    "n_rows": int(count[0]) if count else 0,
                    "sequence_column": column,
                    "id_column": identifier,
                    "n_columns": len(columns),
                }
            )
    return pl.DataFrame(
        rows,
        schema={
            "table": pl.String,
            "n_rows": pl.Int64,
            "sequence_column": pl.String,
            "id_column": pl.String,
            "n_columns": pl.Int64,
        },
    )


def _extracted(path: Path, into: Path) -> Path:
    """The CSV to read: `path` itself, or the single CSV inside it if it is a zip.

    The archive is expanded into `into`, a fresh directory, and macOS resource forks
    (``__MACOSX/._*``) are ignored.
    """
    if path.suffix.lower() != ".zip":
        return path
    with zipfile.ZipFile(path) as archive:
        members = [
            name
            for name in archive.namelist()
            if name.lower().endswith(".csv") and not Path(name).name.startswith("._")
        ]
        if len(members) != 1:
            raise ValueError(f"{path}: expected exactly one CSV inside the zip, found {members}")
        logger.debug("extracting {} from {}", members[0], path.name)
        archive.extract(members[0], into)
        return into / members[0]


def ingest_csv(
    database: Path,
    path: Path,
    *,
    table: str | None = None,
    config: PipelineConfig | None = None,
    replace: bool = False,
) -> TableIndex:
    """Load an assay CSV into `database`, adding its derived IMGT CDRH3.

    The table keeps every column the file had, plus ``cdrh3_imgt``: the IMGT CDR3
    that immunum reads off the row's heavy chain. Where the file already has a
    ``cdrh3`` column it is left untouched, because the two are not interchangeable --
    see the module docstring.

    Args:
        database: the DuckDB file to write into. Created if absent.
        path: a ``.csv``, or a ``.zip`` holding exactly one CSV.
        table: the table to create. Defaults to :func:`table_name` of `path`.
        config: numbering configuration.
        replace: overwrite the table if it already exists.

    Returns:
        A :class:`TableIndex` describing what was written.

    Raises:
        ValueError: if the table exists and `replace` is false, or if the file has no
            recognisable sequence column.
    """
    import time

    config = config or PipelineConfig()
    # Validated before any work: the name reaches SQL by interpolation, and failing
    # here beats failing after a multi-minute numbering pass.
    name = _quote(table)[1:-1] if table else table_name(path)
    started = time.perf_counter()

    with TemporaryDirectory(prefix="abguard-ingest-") as scratch:
        source = _extracted(path, Path(scratch))
        frame = pl.scan_csv(source, infer_schema_length=0)
        columns = frame.collect_schema().names()
        column = next((candidate for candidate in SEQUENCE_COLUMNS if candidate in columns), None)
        if column is None:
            raise ValueError(
                f"{path}: no sequence column; expected one of {', '.join(SEQUENCE_COLUMNS)}, "
                f"found {', '.join(columns)}"
            )
        logger.info("ingesting {} as table {} (numbering {})", path.name, name, column)
        loaded = frame.with_columns(cdrh3_imgt=heavy_cdr3(column, config)).collect()

    n_cdrh3 = int(loaded["cdrh3_imgt"].is_not_null().sum())
    with (
        duckdb.connect(str(database)) as con,
        TemporaryDirectory(prefix="abguard-load-") as staging,
    ):
        exists = con.execute(
            "SELECT count(*) FROM information_schema.tables "
            "WHERE table_schema = 'main' AND table_name = ?",
            [name],
        ).fetchone()
        if exists and exists[0] and not replace:
            raise ValueError(
                f"{database}: table {name!r} already exists; pass replace=True to overwrite it"
            )
        _load(con, loaded, name, Path(staging))

    report = TableIndex(
        table=name,
        column=column,
        n_rows=loaded.height,
        n_cdrh3=n_cdrh3,
        seconds=time.perf_counter() - started,
    )
    logger.success(
        "{}: {} row(s), {} with an IMGT CDRH3, in {:.1f}s",
        name,
        f"{report.n_rows:,}",
        f"{report.n_cdrh3:,}",
        report.seconds,
    )
    return report


def build_cdrh3_index(
    database: Path,
    *,
    tables: list[str] | None = None,
    config: PipelineConfig | None = None,
) -> IndexReport:
    """Derive every reference CDRH3 in `database` and store them in :data:`INDEX_TABLE`.

    This is the slow, once-per-database step: every candidate sequence is IMGT
    numbered, which is the only way to get a CDRH3 that is comparable with a
    design's. :func:`cdrh3_reference` reads the result, so a grading run pays none of
    this cost.

    Args:
        database: the DuckDB file. The index table is written back into it.
        tables: tables to index. Defaults to every table that has one of
            :data:`SEQUENCE_COLUMNS`, which excludes bookkeeping tables like ``arms``.
        config: numbering configuration.

    Returns:
        An :class:`IndexReport`.
    """
    import time

    config = config or PipelineConfig()
    started = time.perf_counter()
    report = IndexReport(database=database)

    available = describe(database).filter(pl.col("sequence_column").is_not_null())
    if tables is not None:
        missing = set(tables) - set(available["table"].to_list())
        if missing:
            raise ValueError(
                f"{database}: no indexable table(s) {', '.join(sorted(missing))}; "
                f"available: {', '.join(available['table'].to_list())}"
            )
        available = available.filter(pl.col("table").is_in(tables))
    if available.is_empty():
        raise ValueError(f"{database}: no table has a sequence column to number")

    logger.info(
        "indexing {} table(s): {}", available.height, ", ".join(available["table"].to_list())
    )

    with duckdb.connect(str(database)) as con, TemporaryDirectory(prefix="abguard-index-") as work:
        scratch = Path(work)
        # Pool every table into one set of distinct sequences before numbering any of
        # them. The arms overlap heavily -- the same antibody is deposited in the PDB,
        # curated into plabdab and claimed in a patent -- and a patent corpus repeats
        # its own sequences too: 13.3M rows hold 4.7M distinct sequences, so numbering
        # rows rather than sequences does 2.9x the work for an identical index.
        # DuckDB does the deduplication, which it is far better at than a round trip.
        union = " UNION ALL ".join(
            f"SELECT {_quote(row['sequence_column'])} AS sequence, "
            f"{_literal_str(row['table'])} AS source, "
            f"{_quote(row['id_column']) if row['id_column'] else 'CAST(NULL AS VARCHAR)'} AS id "
            f"FROM {_quote(row['table'])}"
            for row in available.iter_rows(named=True)
        )
        # `min` over (source, id) picks one representative per sequence deterministically.
        staged = _export(
            con,
            f"SELECT sequence, min(source) AS source, min(id) AS id FROM ({union}) "
            f"WHERE sequence IS NOT NULL GROUP BY sequence",
            scratch / "sequences.parquet",
        )
        n_sequences = int(pl.scan_parquet(staged).select(pl.len()).collect().item())
        n_rows = int(available["n_rows"].sum())
        logger.info(
            "numbering {} distinct sequence(s) from {} row(s) ({:.2f}x less work)",
            f"{n_sequences:,}",
            f"{n_rows:,}",
            n_rows / n_sequences if n_sequences else 1.0,
        )

        # One query for the whole index. Numbering dominates the runtime and polars
        # schedules it across cores either way, so slicing this into per-table or
        # per-batch collects measured no faster (0.98x) -- it only cost the plan its
        # global view. `drop_nulls` runs before the aggregation, and the great majority
        # of a prior-art database is not an antibody, so what accumulates is the ~1M
        # rows that produced a CDRH3 rather than the 4.7M that were numbered.
        index = (
            pl.scan_parquet(staged)
            .select(
                cdrh3=heavy_cdr3("sequence", config),
                source=pl.col("source"),
                id=pl.col("id"),
            )
            .drop_nulls("cdrh3")
            # A sequence immunum numbers but whose CDR3 region comes back empty is not
            # a CDRH3; it would sit in the index matching nothing meaningful.
            .filter(pl.col("cdrh3").str.len_chars() > 0)
            # One row per distinct CDRH3: the gate takes a minimum, which does not care
            # how many depositors hold the same loop. Sorting before `unique` makes the
            # representative deterministic when several entries share a loop.
            .sort("cdrh3", "source", "id", nulls_last=True)
            .unique("cdrh3", keep="first", maintain_order=True)
            .collect()
        )
        report.n_unique = index.height

        contributions = dict(index.group_by("source").len().iter_rows())
        for row in available.iter_rows(named=True):
            report.tables.append(
                TableIndex(
                    table=row["table"],
                    column=row["sequence_column"],
                    n_rows=row["n_rows"],
                    n_cdrh3=contributions.get(row["table"], 0),
                )
            )

        _load(con, index.select("cdrh3", "source", "id"), INDEX_TABLE, scratch)

    report.seconds = time.perf_counter() - started
    logger.success(
        "{}: {} distinct CDRH3 from {} sequence(s) in {:.1f}s",
        INDEX_TABLE,
        f"{report.n_unique:,}",
        f"{report.n_cdrh3:,}",
        report.seconds,
    )
    return report


def reference_cache(database: Path) -> Path:
    """Where :func:`cdrh3_reference` keeps its Parquet copy of the index."""
    return database.with_name(f"{database.name}.{INDEX_TABLE}.parquet")


def _check_provenance(manifest: BundleManifest, config: PipelineConfig, bundle: Path) -> None:
    """Warn when a bundle was indexed differently from how this run numbers designs.

    Not an error: a bundle is a legitimate artifact whoever built it, and refusing it
    would be worse than saying so. But a CDRH3 is only comparable with one derived the
    same way, so a mismatch means wrong verdicts rather than failed ones -- the one
    outcome worth shouting about.
    """
    if manifest.scheme != config.scheme:
        logger.warning(
            "{}: indexed with scheme {!r} but this run numbers with {!r}; CDRH3 regions "
            "are not comparable across schemes",
            bundle.name,
            manifest.scheme,
            config.scheme,
        )
    if manifest.min_confidence != config.min_confidence:
        logger.warning(
            "{}: indexed at confidence {} but this run uses {}; borderline reference "
            "sequences may be numbered differently than the designs they are compared with",
            bundle.name,
            manifest.min_confidence,
            config.min_confidence,
        )


def cdrh3_reference(
    reference: Path,
    *,
    cache: Path | None = None,
    refresh: bool = False,
    config: PipelineConfig | None = None,
) -> pl.LazyFrame:
    """Read the CDRH3 index out of a reference as a lazy ``(cdrh3, source)`` frame.

    `reference` is either a Parquet bundle (:func:`export_bundle`) or a DuckDB
    database. A bundle is already Parquet, so it is scanned in place. A database is
    exported to a Parquet sidecar (see :func:`reference_cache`) and scanned from
    there, rebuilt whenever it is older than the database or on `refresh`. Either way
    the result is a genuine :class:`polars.LazyFrame` the novelty join can stream
    rather than a table held in memory.

    Args:
        reference: a bundle directory, or a DuckDB file that
            :func:`build_cdrh3_index` has been run on.
        cache: override the sidecar location. Ignored for a bundle.
        refresh: re-export even if the sidecar looks current. Ignored for a bundle.
        config: the numbering configuration this run uses, checked against a bundle's
            recorded provenance.

    Returns:
        The reference, lazily, ready to hand to
        :func:`~abguard.novelty.with_novelty`.

    Raises:
        ValueError: if the index is absent, which means the reference has not been
            indexed yet.
    """
    if is_bundle(reference):
        manifest = read_manifest(reference)
        _check_provenance(manifest, config or PipelineConfig(), reference)
        logger.debug("{}: reading {} from the bundle", reference.name, manifest.index_table)
        return bundle_table(reference, manifest.index_table)

    database = reference
    destination = cache or reference_cache(database)
    current = (
        destination.exists()
        and database.exists()
        and destination.stat().st_mtime >= database.stat().st_mtime
    )
    if refresh or not current:
        with duckdb.connect(str(database), read_only=True) as con:
            exists = con.execute(
                "SELECT count(*) FROM information_schema.tables "
                "WHERE table_schema = 'main' AND table_name = ?",
                [INDEX_TABLE],
            ).fetchone()
            if not exists or not exists[0]:
                raise ValueError(
                    f"{database}: no {INDEX_TABLE!r} table; run `abguard reference-build "
                    f"{database}` once to derive the reference CDRH3s"
                )
            logger.debug("exporting {} to {}", INDEX_TABLE, destination.name)
            # `id` is selected explicitly rather than with `*` so an index built by an
            # older abguard, which did not carry it, still loads.
            columns = {
                name
                for (name,) in con.execute(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_schema = 'main' AND table_name = ?",
                    [INDEX_TABLE],
                ).fetchall()
            }
            identifier = "id" if "id" in columns else "CAST(NULL AS VARCHAR) AS id"
            _export(
                con,
                f"SELECT cdrh3, source, {identifier} FROM {_quote(INDEX_TABLE)}",
                destination,
            )
    return pl.scan_parquet(destination)


# ---------------------------------------------------------------------------------
# Shipping a reference as Parquet
# ---------------------------------------------------------------------------------
#
# A DuckDB file is the wrong shape to hand around: it is 4.2 GB, it is a single
# mutable database with one writer, and reading it needs duckdb. A bundle is the same
# content as Parquet -- one file per table, zstd compressed, plus a manifest -- which
# polars scans natively and lazily, with projection pushdown, and which compresses far
# better because Parquet is columnar and CDRH3s repeat heavily.
#
# Delta Lake and Iceberg were the alternatives. Both are also a directory per table
# underneath, both need a dependency this package would not otherwise have
# (``deltalake``/``pyiceberg``), and both buy transaction logs, schema evolution and
# time travel that a read-only shipped artifact never uses. Plain Parquet plus a
# manifest is the same multi-table capability with none of that.


#: Name of the manifest inside a bundle.
BUNDLE_MANIFEST = "manifest.json"

#: Bundle layout version. Bumped if the layout changes incompatibly.
BUNDLE_FORMAT = 1

#: zstd level :func:`export_bundle` writes at. A bundle is written once and read many
#: times, so the slow end of the scale is free: level 19 takes the HER2 reference from
#: 2.97 MB to 2.15 MB for identical content. Level 22 gains nothing further.
DEFAULT_COMPRESSION_LEVEL = 19

#: Where a reference bundle shipped inside the package lives.
BUNDLED_REFERENCE = "reference_data"


class BundleTable(BaseModel):
    """One table inside a bundle."""

    table: str
    n_rows: int
    sequence_column: str | None = Field(
        default=None, description="the column `build_cdrh3_index` would number, if any"
    )
    n_bytes: int = Field(description="size of the Parquet file")

    @property
    def filename(self) -> str:
        return f"{self.table}.parquet"


class BundleManifest(BaseModel):
    """What a bundle contains and how its CDRH3 index was derived.

    The provenance fields are the point. A CDRH3 index is only comparable with a
    submission numbered the same way, so a bundle that did not record its scheme and
    confidence floor could not be checked against the code reading it --
    :func:`cdrh3_reference` warns when they differ, because the result would be a
    silently wrong verdict rather than an error.
    """

    format: int = BUNDLE_FORMAT
    abguard_version: str
    scheme: str = Field(description="immunum numbering scheme the index was built with")
    min_confidence: float = Field(description="confidence floor the index was built with")
    index_table: str = INDEX_TABLE
    compression: str
    tables: list[BundleTable] = Field(default_factory=list)

    @property
    def n_bytes(self) -> int:
        return sum(table.n_bytes for table in self.tables)

    def table(self, name: str) -> BundleTable | None:
        return next((entry for entry in self.tables if entry.table == name), None)


def bundled_reference() -> Path | None:
    """The reference bundle shipped inside the package, if there is one.

    Makes the novelty gate work from a bare ``uvx`` with no data to fetch and no
    database to build: the index is 2.15 MB of Parquet, so it travels in the wheel.
    A ``--reference-db`` always wins over it, since a locally built index can be newer
    or hold more than whatever was current when the package was cut.
    """
    from importlib.resources import files

    try:
        candidate = Path(str(files("abguard") / BUNDLED_REFERENCE))
    except (ModuleNotFoundError, TypeError):  # pragma: no cover - importlib edge cases
        return None
    return candidate if is_bundle(candidate) else None


def is_bundle(path: Path) -> bool:
    """True when `path` is a Parquet reference bundle rather than a DuckDB file."""
    return path.is_dir() and (path / BUNDLE_MANIFEST).is_file()


def read_manifest(bundle: Path) -> BundleManifest:
    """Parse a bundle's manifest.

    Raises:
        ValueError: if `bundle` has no manifest, or its layout is from a newer abguard.
    """
    manifest_path = bundle / BUNDLE_MANIFEST
    if not manifest_path.is_file():
        raise ValueError(f"{bundle}: not a reference bundle; no {BUNDLE_MANIFEST}")
    manifest = BundleManifest.model_validate_json(manifest_path.read_text())
    if manifest.format > BUNDLE_FORMAT:
        raise ValueError(
            f"{bundle}: bundle format {manifest.format} is newer than this abguard "
            f"understands ({BUNDLE_FORMAT}); upgrade abguard"
        )
    return manifest


def bundle_table(bundle: Path, table: str) -> pl.LazyFrame:
    """Scan one table out of a bundle, lazily.

    Raises:
        ValueError: if the bundle does not hold `table`.
    """
    manifest = read_manifest(bundle)
    entry = manifest.table(table)
    if entry is None:
        raise ValueError(
            f"{bundle}: no table {table!r}; holds {', '.join(e.table for e in manifest.tables)}"
        )
    return pl.scan_parquet(bundle / entry.filename)


def export_bundle(
    source: Path,
    destination: Path,
    *,
    tables: list[str] | None = None,
    compression: str = "zstd",
    compression_level: int | None = None,
    config: PipelineConfig | None = None,
) -> BundleManifest:
    """Write `source` out as a Parquet reference bundle at `destination`.

    Args:
        source: a DuckDB reference database, already indexed with
            :func:`build_cdrh3_index`.
        destination: directory to create. Existing Parquet files in it are replaced.
        tables: extra tables to include alongside the CDRH3 index. The default is the
            index alone, because that is the whole of what the gate reads: 2.3 MB for
            the 610k loops derived from a 4.2 GB database. Adding the arms back means
            shipping their raw sequences -- ``uspto`` alone is 1.2 GB as Parquet --
            which is worth it only if the recipient needs to re-derive the index or
            trace a hit back to its depositor.
        compression: Parquet codec. ``zstd`` by default.
        compression_level: codec level. When None, zstd gets
            :data:`DEFAULT_COMPRESSION_LEVEL` and any other codec gets its own default
            -- levels are codec-specific, and 19 is meaningless to snappy and out of
            range for gzip.
        config: the numbering configuration the index was built with, recorded in the
            manifest as provenance.

    Returns:
        The :class:`BundleManifest` written.

    Raises:
        ValueError: if `source` has no CDRH3 index to ship.
    """
    import time

    from . import __version__

    config = config or PipelineConfig()
    started = time.perf_counter()
    available = _describe_duckdb(source)
    names = set(available["table"].to_list())
    if INDEX_TABLE not in names:
        raise ValueError(
            f"{source}: no {INDEX_TABLE!r} table to ship; run `abguard reference-build "
            f"{source}` first"
        )
    if tables is None:
        wanted = [INDEX_TABLE]
    else:
        missing = set(tables) - names
        if missing:
            raise ValueError(
                f"{source}: no table(s) {', '.join(sorted(missing))}; "
                f"holds {', '.join(sorted(names))}"
            )
        wanted = list(dict.fromkeys([INDEX_TABLE, *tables]))

    destination.mkdir(parents=True, exist_ok=True)
    manifest = BundleManifest(
        abguard_version=__version__,
        scheme=config.scheme,
        min_confidence=config.min_confidence,
        compression=compression,
    )
    if compression_level is None and compression.lower() == "zstd":
        compression_level = DEFAULT_COMPRESSION_LEVEL
    options = f"FORMAT PARQUET, COMPRESSION {compression.upper()}"
    if compression_level is not None:
        options += f", COMPRESSION_LEVEL {int(compression_level)}"

    with duckdb.connect(str(source), read_only=True) as con:
        for name in dict.fromkeys(wanted):
            target = destination / f"{name}.parquet"
            # DuckDB writes the Parquet itself, so a multi-million-row table never
            # passes through memory on the way out.
            con.execute(f"COPY (SELECT * FROM {_quote(name)}) TO {_literal(target)} ({options})")
            row = available.filter(pl.col("table") == name).row(0, named=True)
            manifest.tables.append(
                BundleTable(
                    table=name,
                    n_rows=row["n_rows"],
                    sequence_column=row["sequence_column"],
                    n_bytes=target.stat().st_size,
                )
            )
            logger.info(
                "{}: {} row(s), {:.1f} MB {}",
                target.name,
                f"{row['n_rows']:,}",
                target.stat().st_size / 1e6,
                compression,
            )

    (destination / BUNDLE_MANIFEST).write_text(manifest.model_dump_json(indent=2) + "\n")
    logger.success(
        "{}: {} table(s), {:.1f} MB total in {:.1f}s",
        destination,
        len(manifest.tables),
        manifest.n_bytes / 1e6,
        time.perf_counter() - started,
    )
    return manifest


def _describe_bundle(bundle: Path) -> pl.DataFrame:
    """:func:`describe` for a Parquet bundle."""
    manifest = read_manifest(bundle)
    return pl.DataFrame(
        [
            {
                "table": entry.table,
                "n_rows": entry.n_rows,
                "sequence_column": entry.sequence_column,
                "id_column": None,
                "n_bytes": entry.n_bytes,
            }
            for entry in manifest.tables
        ],
        schema={
            "table": pl.String,
            "n_rows": pl.Int64,
            "sequence_column": pl.String,
            "id_column": pl.String,
            "n_bytes": pl.Int64,
        },
    )


def describe(reference: Path) -> pl.DataFrame:
    """Every table in a reference, with its row count and sequence column.

    Accepts either a DuckDB database or a Parquet bundle.
    """
    return _describe_bundle(reference) if is_bundle(reference) else _describe_duckdb(reference)
