"""Dataframely schemas for design submission tables.

Three formats are accepted, one per :class:`~abguard.config.DesignKind`. The
distinguishing rule is how many variable domains immunum must find in each column:

==========  ==================================  ================
kind        ``heavy_sequence``                  ``light_sequence``
==========  ==================================  ================
``vhh``     one IGH domain                      must be empty
``scfv``    two domains, either orientation     must be empty
``paired``  one IGH domain                      one IGK/IGL domain
==========  ==================================  ================

``vhh`` and ``scfv`` are both a single polypeptide, so both put it in
``heavy_sequence`` and leave ``light_sequence`` empty; they differ only in the domain
count. The 250-residue cap is sized for the scFv case: a VH-linker-VL construct runs
to roughly 240 residues.

:class:`DesignLibrary` is the compound schema -- a dataframely collection with one
member per kind, so a submission table is split on ``kind`` and each partition is
validated against its own schema.

Every hard check here has a matching :class:`~abguard.config.ErrorKind`, which is what
``--all-liabilities`` reports per row:

- ``invalid_amino_acids`` -- the column ``regex``
- ``sequence_too_long`` -- the column ``max_length``
- ``unpaired_cysteine`` -- an odd number of cysteines in a column or in one domain
- ``numbering_failed`` -- immunum cannot number a domain under IMGT
- ``wrong_domain_count`` -- the wrong number of domains for the kind
- ``missing_sequence`` / ``unexpected_sequence`` -- column presence per kind
- ``duplicate_sequence_id`` -- ``sequence_id`` is the primary key
"""

#
# NOTE: `from __future__ import annotations` must NOT be added to this module.
# dataframely inspects `DesignLibrary`'s annotations at class-creation time and
# cannot resolve them if they are strings.
#
import dataframely as dy
import immunum.polars as imp
import polars as pl

from .config import (
    AMINO_ACID_REGEX,
    ANY_IG,
    DOMAIN_SPEC,
    MAX_SEQUENCE_LENGTH,
    MIN_CONFIDENCE,
    Chain,
    DesignKind,
    DomainSpec,
    sequence_column,
)

__all__ = [
    "INPUT_COLUMNS",
    "SCHEMA_BY_KIND",
    "SCHEME",
    "DesignLibrary",
    "DesignSchema",
    "PairedAntibodySchema",
    "ScFvSchema",
    "VHHSchema",
    "column_cysteines_are_paired",
    "domain_cysteines_are_paired",
    "domains",
    "has_expected_domains",
]

#: The numbering scheme is not configurable: the missing/extra-cysteine liability
#: rules are defined on IMGT positions 23 and 104.
SCHEME = "imgt"


def domains(column: str, chains: list[str]) -> pl.Expr:
    """The ``immunum.polars.number_domains`` list for `column`.

    Null for a null sequence. A sequence with no recognisable domain comes back as a
    one-element list whose ``error_kind`` is set, so the count alone never tells you
    a sequence numbered cleanly -- see :func:`has_expected_domains`.

    ``min_confidence`` is passed explicitly from :data:`~abguard.config.MIN_CONFIDENCE`
    rather than left to immunum's own default. These rules are the gate, and
    :mod:`abguard.annotate` reports against the same constant: letting the two take
    different values is how a design comes back valid with its errors listed, or
    invalid with none.
    """
    return imp.number_domains(column, chains=chains, scheme=SCHEME, min_confidence=MIN_CONFIDENCE)


def has_expected_domains(column: str, spec: DomainSpec) -> pl.Expr:
    """True when `column` holds exactly the domains `spec` requires.

    Three things matter: the count must match, no domain may carry an ``error_kind``
    (which is how immunum reports a sequence it could not number confidently, or a
    stretch too short to be a domain), and every domain must be of a chain type the
    spec allows.

    The chain type is checked against the label immunum assigns when offered all of
    IGH/IGK/IGL, not by asking it for heavy chains only. Restricting the chain set
    makes the confidence floor the sole barrier against a light chain being force-fit
    as a heavy one -- see :data:`~abguard.config.ANY_IG`. This is what rejects a
    ``paired`` design whose heavy and light columns are swapped.
    """
    found = domains(column, ANY_IG)
    return (found.list.len() == spec.n_domains) & found.list.eval(
        pl.element().struct.field("error_kind").is_null()
        & pl.element().struct.field("chain").is_in(spec.labels)
    ).list.all()


def column_cysteines_are_paired(column: str) -> pl.Expr:
    """True when the whole of `column` holds an even number of cysteines.

    Catches an unpaired cysteine anywhere in the submitted polypeptide, including the
    parts immunum does not number such as an scFv linker or a terminal tag.
    """
    return pl.col(column).str.count_matches("C") % 2 == 0


def domain_cysteines_are_paired(column: str, spec: DomainSpec) -> pl.Expr:
    """True when every variable domain in `column` holds an even number of cysteines.

    Stricter than :func:`column_cysteines_are_paired` for a multi-domain construct: an
    scFv whose VH and VL each carry one spare cysteine has an even count overall, but
    neither spare can pair, because the two domains fold separately and variable
    domains have no interchain disulfide.
    """
    return (
        domains(column, ANY_IG)
        .list.eval(
            pl.element()
            .struct.field("numbering")
            .list.eval((pl.element().struct.field("residue") == "C").cast(pl.Int32))
            .list.sum()
            % 2
            == 0
        )
        .list.all()
    )


def _sequence_column(*, nullable: bool = False) -> dy.String:
    return dy.String(
        nullable=nullable,
        min_length=1,
        max_length=MAX_SEQUENCE_LENGTH,
        regex=AMINO_ACID_REGEX,
    )


class DesignSchema(dy.Schema):
    """Columns shared by every submission format.

    Subclasses pin ``kind`` to a single value and add the domain-count and cysteine
    rules for the columns that kind uses.
    """

    sequence_id = dy.String(primary_key=True, min_length=1)
    heavy_sequence = _sequence_column()
    design_description = dy.String(nullable=False)


class _SingleChainSchema(DesignSchema):
    """A format submitted as one polypeptide in ``heavy_sequence``."""

    light_sequence = dy.String(nullable=True, min_length=1)

    @dy.rule()
    def has_no_light_chain(cls) -> pl.Expr:
        return pl.col("light_sequence").is_null()

    @dy.rule()
    def heavy_cysteines_are_paired(cls) -> pl.Expr:
        return column_cysteines_are_paired("heavy_sequence")

    @dy.rule()
    def heavy_domain_cysteines_are_paired(cls) -> pl.Expr:
        return domain_cysteines_are_paired("heavy_sequence", DOMAIN_SPEC[cls.kind_()][Chain.HEAVY])

    @dy.rule()
    def heavy_has_expected_domains(cls) -> pl.Expr:
        return has_expected_domains("heavy_sequence", DOMAIN_SPEC[cls.kind_()][Chain.HEAVY])


class VHHSchema(_SingleChainSchema):
    """A single heavy-chain variable domain. One IGH domain, no light chain."""

    kind = dy.Enum([DesignKind.VHH.value])

    @classmethod
    def kind_(cls) -> DesignKind:
        return DesignKind.VHH


class ScFvSchema(_SingleChainSchema):
    """A single-chain variable fragment: two variable domains joined by a linker.

    Either orientation is accepted, so the domains' chain types are unconstrained --
    only that immunum finds exactly two of them and numbers both.
    """

    kind = dy.Enum([DesignKind.SCFV.value])

    @classmethod
    def kind_(cls) -> DesignKind:
        return DesignKind.SCFV


class PairedAntibodySchema(DesignSchema):
    """A paired antibody variable region: one IGH domain plus one IGK/IGL domain."""

    kind = dy.Enum([DesignKind.PAIRED.value])
    light_sequence = _sequence_column()

    @classmethod
    def kind_(cls) -> DesignKind:
        return DesignKind.PAIRED

    @dy.rule()
    def heavy_cysteines_are_paired(cls) -> pl.Expr:
        return column_cysteines_are_paired("heavy_sequence")

    @dy.rule()
    def light_cysteines_are_paired(cls) -> pl.Expr:
        return column_cysteines_are_paired("light_sequence")

    @dy.rule()
    def heavy_has_expected_domains(cls) -> pl.Expr:
        return has_expected_domains("heavy_sequence", DOMAIN_SPEC[DesignKind.PAIRED][Chain.HEAVY])

    @dy.rule()
    def light_has_expected_domains(cls) -> pl.Expr:
        return has_expected_domains("light_sequence", DOMAIN_SPEC[DesignKind.PAIRED][Chain.LIGHT])


class DesignLibrary(dy.Collection):
    """The compound schema: one member per design format.

    Every member is optional, so a team may submit any mix of the three formats.
    """

    vhh: dy.LazyFrame[VHHSchema] | None
    scfv: dy.LazyFrame[ScFvSchema] | None
    paired: dy.LazyFrame[PairedAntibodySchema] | None


SCHEMA_BY_KIND: dict[DesignKind, type[DesignSchema]] = {
    DesignKind.VHH: VHHSchema,
    DesignKind.SCFV: ScFvSchema,
    DesignKind.PAIRED: PairedAntibodySchema,
}

#: Columns an input file must provide.
INPUT_COLUMNS = (
    "sequence_id",
    "kind",
    sequence_column(Chain.HEAVY),
    sequence_column(Chain.LIGHT),
    "design_description",
)
